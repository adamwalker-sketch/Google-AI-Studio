import React from 'react';
import { SummaryStats } from '../types';
import { METRICS } from '../constants';
import { ArrowUp, ArrowDown, Minus } from 'lucide-react';

interface SummaryCardsProps {
  stats: SummaryStats;
}

const SummaryCards: React.FC<SummaryCardsProps> = ({ stats }) => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
      {METRICS.map(metric => {
        const stat = stats[metric.key];
        if (!stat) return null;

        const isPositive = stat.change > 0;
        const isNeutral = stat.change === 0;
        
        // For search volume, up is good (green). For others (shares), up is usually good too.
        
        const formatValue = (val: number) => {
          if (metric.format === 'percent') return `${val.toFixed(2)}%`;
          return val.toLocaleString(undefined, { maximumFractionDigits: 0 });
        };

        return (
          <div key={metric.key} className="bg-pattern-card p-4 rounded-xl shadow-lg border border-pattern-border hover:border-pattern-blue/30 transition-all">
            <h3 className="text-xs font-semibold text-pattern-muted uppercase mb-1">{metric.label}</h3>
            <div className="flex items-baseline gap-2 mb-2">
              <span className="text-2xl font-bold text-white">
                {formatValue(stat.current)}
              </span>
            </div>
            
            <div className="flex items-center text-xs">
                <span className={`flex items-center font-medium px-1.5 py-0.5 rounded ${
                    isNeutral ? 'bg-slate-800 text-slate-400' :
                    isPositive ? 'bg-emerald-900/50 text-emerald-400 border border-emerald-900' : 'bg-red-900/50 text-red-400 border border-red-900'
                }`}>
                    {isNeutral && <Minus className="w-3 h-3 mr-1" />}
                    {!isNeutral && isPositive && <ArrowUp className="w-3 h-3 mr-1" />}
                    {!isNeutral && !isPositive && <ArrowDown className="w-3 h-3 mr-1" />}
                    {Math.abs(stat.change).toFixed(1)}%
                </span>
                <span className="ml-2 text-pattern-muted">vs prev.</span>
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default SummaryCards;