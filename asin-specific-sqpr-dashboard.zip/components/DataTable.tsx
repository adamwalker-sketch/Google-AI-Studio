
import React, { useState, useMemo } from 'react';
import { AggregatedDataPoint } from '../types';
import { METRICS } from '../constants';
import { ArrowUp, ArrowDown, ArrowUpDown, Download } from 'lucide-react';

interface DataTableProps {
  data: AggregatedDataPoint[];
}

type SortDirection = 'asc' | 'desc';

interface SortConfig {
  key: string;
  direction: SortDirection;
}

const DataTable: React.FC<DataTableProps> = ({ data }) => {
  const [sortConfig, setSortConfig] = useState<SortConfig>({ 
    key: 'date', 
    direction: 'desc' 
  });

  const handleSort = (key: string) => {
    setSortConfig(current => {
      if (current.key === key) {
        return { key, direction: current.direction === 'asc' ? 'desc' : 'asc' };
      }
      return { key, direction: 'desc' };
    });
  };

  const sortedData = useMemo(() => {
    const sortableData = [...data];
    if (sortConfig.key) {
      sortableData.sort((a, b) => {
        const valA = a[sortConfig.key];
        const valB = b[sortConfig.key];

        if (valA < valB) return sortConfig.direction === 'asc' ? -1 : 1;
        if (valA > valB) return sortConfig.direction === 'asc' ? 1 : -1;
        return 0;
      });
    }
    return sortableData;
  }, [data, sortConfig]);

  const downloadCSV = () => {
    const headers = ['Date', ...METRICS.map(m => m.label)];
    const rows = sortedData.map(row => {
      const metricValues = METRICS.map(m => row[m.key as string]);
      return [row.date, ...metricValues].join(',');
    });
    
    const csvContent = [headers.join(','), ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `detailed_trends_data_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const SortIcon = ({ columnKey }: { columnKey: string }) => {
    if (sortConfig.key !== columnKey) {
      return <ArrowUpDown className="w-3 h-3 text-slate-600 opacity-0 group-hover:opacity-100 transition-opacity" />;
    }
    return sortConfig.direction === 'asc' 
      ? <ArrowUp className="w-3 h-3 text-pattern-blue" />
      : <ArrowDown className="w-3 h-3 text-pattern-blue" />;
  };

  return (
    <div className="bg-pattern-card rounded-xl shadow-lg border border-pattern-border overflow-hidden mb-8">
      <div className="p-4 border-b border-pattern-border flex justify-between items-center">
        <h2 className="text-lg font-bold text-white">Detailed Data</h2>
        <button
            onClick={downloadCSV}
            className="p-2 rounded-lg transition-colors bg-slate-800 text-pattern-muted hover:text-white hover:bg-slate-700"
            title="Download CSV"
        >
            <Download className="w-4 h-4" />
        </button>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm text-left">
          <thead className="bg-slate-800 text-pattern-muted uppercase text-xs">
            <tr>
              <th 
                className="px-6 py-3 font-medium border-b border-pattern-border cursor-pointer group hover:bg-slate-700 transition-colors select-none"
                onClick={() => handleSort('date')}
              >
                <div className="flex items-center gap-2">
                  Date
                  <SortIcon columnKey="date" />
                </div>
              </th>
              {METRICS.map(m => (
                <th 
                  key={m.key} 
                  className="px-6 py-3 font-medium text-right whitespace-nowrap border-b border-pattern-border cursor-pointer group hover:bg-slate-700 transition-colors select-none"
                  onClick={() => handleSort(m.key as string)}
                >
                  <div className="flex items-center justify-end gap-2">
                    {m.label}
                    <SortIcon columnKey={m.key as string} />
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-pattern-border">
            {sortedData.map((row, idx) => (
              <tr key={idx} className="hover:bg-slate-800/50 transition-colors">
                <td className="px-6 py-4 font-medium text-white whitespace-nowrap">
                  {row.date}
                </td>
                {METRICS.map(m => (
                  <td key={m.key} className="px-6 py-4 text-right text-pattern-muted">
                    {m.format === 'percent' 
                      ? `${(row[m.key] as number).toFixed(2)}%`
                      : (row[m.key] as number).toLocaleString(undefined, { maximumFractionDigits: 0 })}
                  </td>
                ))}
              </tr>
            ))}
            {sortedData.length === 0 && (
              <tr>
                <td colSpan={METRICS.length + 1} className="px-6 py-8 text-center text-pattern-muted">
                  No data available for the selected filters.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default DataTable;
