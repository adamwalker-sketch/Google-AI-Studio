import React, { useState } from 'react';
import { FilterState, SearchMode } from '../types';
import { TIME_GRAINS } from '../constants';
import { Calendar, ShoppingBag, BarChart2, Search, ChevronDown, X } from 'lucide-react';

interface FilterBarProps {
  filters: FilterState;
  onFilterChange: (newFilters: FilterState) => void;
  availableMarketplaces: string[];
  availableAsins: string[];
  availableSearchQueries: string[];
}

const FilterBar: React.FC<FilterBarProps> = ({ 
    filters, 
    onFilterChange, 
    availableAsins
}) => {
  const [isRegexError, setIsRegexError] = useState(false);

  const handleDateChange = (type: 'start' | 'end', value: string) => {
    if (!value) return;

    let newDate = value;
    if (type === 'start') {
        newDate = `${value}-01`;
    } else {
        const [y, m] = value.split('-').map(Number);
        const date = new Date(y, m, 0); 
        const day = String(date.getDate()).padStart(2, '0');
        newDate = `${value}-${day}`;
    }

    onFilterChange({
      ...filters,
      dateRange: { ...filters.dateRange, [type]: newDate }
    });
  };

  const handleAsinToggle = (asin: string) => {
    const current = filters.selectedAsins;
    let newSelection;
    if (current.includes(asin)) {
      newSelection = current.filter(a => a !== asin);
    } else {
      newSelection = [...current, asin];
    }
    onFilterChange({ ...filters, selectedAsins: newSelection });
  };

  const handleSearchChange = (value: string) => {
    if (filters.searchQueryMode === 'regex') {
        try {
            if (value) new RegExp(value);
            setIsRegexError(false);
        } catch (e) {
            setIsRegexError(true);
        }
    } else {
        setIsRegexError(false);
    }
    onFilterChange({ ...filters, searchQueryFilter: value });
  };

  const handleModeChange = (mode: SearchMode) => {
    setIsRegexError(false);
    onFilterChange({ ...filters, searchQueryMode: mode });
  };

  const clearSearch = () => {
    onFilterChange({ ...filters, searchQueryFilter: '' });
    setIsRegexError(false);
  };

  return (
    <div className="bg-pattern-card p-5 rounded-xl shadow-lg border border-pattern-border mb-6 sticky top-[64px] z-20">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-x-4 gap-y-6 items-end">
        
        {/* Search Terms Section - lg:col-span-5 to leave room for others */}
        <div className="lg:col-span-5 flex flex-col gap-1.5">
            <label className="text-[10px] font-bold text-pattern-muted uppercase tracking-wider flex items-center gap-1.5 px-1">
                <Search className="w-3.5 h-3.5" /> Search Terms
            </label>
            <div className={`relative flex items-center bg-pattern-input border-2 rounded-lg transition-all duration-200 overflow-hidden ${isRegexError ? 'border-red-500 shadow-[0_0_10px_rgba(239,68,68,0.2)]' : 'border-pattern-blue shadow-[0_0_15px_rgba(56,189,248,0.1)]'}`}>
                {/* Mode Selector Dropdown */}
                <div className="relative border-r border-slate-700/50 flex-shrink-0">
                    <select 
                        value={filters.searchQueryMode}
                        onChange={(e) => handleModeChange(e.target.value as SearchMode)}
                        className="appearance-none bg-transparent text-slate-300 text-sm py-2 pl-3 pr-7 outline-none cursor-pointer hover:text-white transition-colors capitalize min-w-[85px]"
                    >
                        <option value="phrase" className="bg-slate-900">Phrase</option>
                        <option value="exact" className="bg-slate-900">Exact</option>
                        <option value="regex" className="bg-slate-900">Regex</option>
                    </select>
                    <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-500 pointer-events-none" />
                </div>

                {/* Input Field */}
                <input 
                    type="text" 
                    placeholder={filters.searchQueryMode === 'regex' ? 'Enter regex...' : 'turmeric supplement'} 
                    className="flex-1 bg-transparent text-white text-sm py-2 px-3 outline-none placeholder-slate-700 w-full"
                    value={filters.searchQueryFilter}
                    onChange={(e) => handleSearchChange(e.target.value)}
                />

                {/* Clear Button */}
                {filters.searchQueryFilter && (
                    <button 
                        onClick={clearSearch}
                        className="p-2 mr-1 text-slate-600 hover:text-slate-300 transition-colors"
                        title="Clear Search"
                    >
                        <X className="w-3.5 h-3.5" />
                    </button>
                )}
            </div>
        </div>

        {/* Date Range - lg:col-span-4 */}
        <div className="lg:col-span-4 flex flex-col gap-1.5">
          <label className="text-[10px] font-bold text-pattern-muted uppercase tracking-wider flex items-center gap-1.5 px-1">
            <Calendar className="w-3.5 h-3.5" /> Date Range
          </label>
          <div className="flex gap-2 w-full">
            <div className="relative flex-1">
                <input
                    type="month"
                    className="bg-pattern-input border border-pattern-border rounded-lg px-3 py-2 text-xs w-full focus:ring-1 focus:ring-pattern-blue outline-none text-white transition-all hover:border-slate-700"
                    value={filters.dateRange.start.substring(0, 7)}
                    onChange={(e) => handleDateChange('start', e.target.value)}
                />
            </div>
            <div className="relative flex-1">
                <input
                    type="month"
                    className="bg-pattern-input border border-pattern-border rounded-lg px-3 py-2 text-xs w-full focus:ring-1 focus:ring-pattern-blue outline-none text-white transition-all hover:border-slate-700"
                    value={filters.dateRange.end.substring(0, 7)}
                    onChange={(e) => handleDateChange('end', e.target.value)}
                />
            </div>
          </div>
        </div>

        {/* Products - lg:col-span-2 */}
        <div className="lg:col-span-2 flex flex-col gap-1.5 group relative">
            <label className="text-[10px] font-bold text-pattern-muted uppercase tracking-wider flex items-center gap-1.5 px-1">
                <ShoppingBag className="w-3.5 h-3.5" /> Products
            </label>
            <div className="relative">
                <button className="bg-pattern-input border border-pattern-border rounded-lg px-3 py-2 text-xs w-full text-left text-white focus:ring-1 focus:ring-pattern-blue outline-none truncate hover:border-slate-700 transition-all flex justify-between items-center h-[38px]">
                    <span className="truncate pr-2">
                        {filters.selectedAsins.length === 0 
                            ? "All Products" 
                            : `${filters.selectedAsins.length} Selected`}
                    </span>
                    <ChevronDown className="w-3.5 h-3.5 text-slate-500 flex-shrink-0" />
                </button>
                
                {/* Custom Dropdown Content */}
                <div className="invisible group-hover:visible opacity-0 group-hover:opacity-100 absolute top-full left-0 w-full max-h-60 overflow-y-auto bg-slate-900 border border-pattern-border shadow-2xl rounded-lg mt-1 z-40 p-2 transition-all duration-200 translate-y-2 group-hover:translate-y-0 min-w-[180px]">
                    <div 
                        className="p-1.5 hover:bg-slate-800 rounded cursor-pointer text-[10px] font-bold border-b border-pattern-border mb-1 text-pattern-blue text-center uppercase"
                        onClick={() => onFilterChange({ ...filters, selectedAsins: [] })}
                    >
                        Reset Selection
                    </div>
                    {availableAsins.map(asin => (
                        <label key={asin} className="flex items-center gap-2 p-2 hover:bg-slate-800 rounded cursor-pointer text-xs text-slate-400 hover:text-white transition-colors">
                            <input 
                                type="checkbox" 
                                checked={filters.selectedAsins.includes(asin)}
                                onChange={() => handleAsinToggle(asin)}
                                className="rounded bg-slate-800 border-slate-700 text-pattern-blue focus:ring-pattern-blue accent-pattern-blue w-3.5 h-3.5"
                            />
                            <span className="truncate text-[11px]" title={asin}>{asin}</span>
                        </label>
                    ))}
                    {availableAsins.length === 0 && (
                        <div className="p-2 text-center text-xs text-slate-600 italic">No products available</div>
                    )}
                </div>
            </div>
        </div>

        {/* Aggregation - lg:col-span-1 */}
        <div className="lg:col-span-1 flex flex-col gap-1.5 min-w-[70px]">
            <label className="text-[10px] font-bold text-pattern-muted uppercase tracking-wider flex items-center gap-1.5 px-1 whitespace-nowrap">
                <BarChart2 className="w-3.5 h-3.5" /> Agg.
            </label>
            <div className="relative">
                <select
                    className="appearance-none bg-pattern-input border border-pattern-border rounded-lg px-3 py-2 text-xs w-full focus:ring-1 focus:ring-pattern-blue outline-none text-white cursor-pointer hover:border-slate-700 transition-all h-[38px]"
                    value={filters.timeGrain}
                    onChange={(e) => onFilterChange({ ...filters, timeGrain: e.target.value as any })}
                >
                    {TIME_GRAINS.map(g => (
                        <option key={g.value} value={g.value} className="bg-slate-900">{g.label.charAt(0)}</option>
                    ))}
                </select>
                <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-500 pointer-events-none" />
            </div>
        </div>

      </div>
    </div>
  );
};

export default FilterBar;