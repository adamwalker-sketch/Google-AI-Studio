
import React, { useState } from 'react';
import { Sparkles, RefreshCw } from 'lucide-react';

interface AIInsightsProps {
  onGenerate: () => Promise<string>;
}

const AIInsights: React.FC<AIInsightsProps> = ({ onGenerate }) => {
  const [insight, setInsight] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleGenerate = async () => {
    setLoading(true);
    const result = await onGenerate();
    setInsight(result);
    setLoading(false);
  };

  return (
    <div className="bg-gradient-to-r from-slate-900 to-slate-800 rounded-xl shadow-lg border border-indigo-500/30 p-6 mb-6 relative overflow-hidden">
      <div className="absolute top-0 right-0 p-4 opacity-10">
        <Sparkles className="w-24 h-24 text-indigo-400" />
      </div>
      
      <div className="relative z-10">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-indigo-400" />
            <h2 className="text-lg font-bold text-white">Gemini Intelligence</h2>
          </div>
          <button
            onClick={handleGenerate}
            disabled={loading}
            className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-medium rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-indigo-500/20"
          >
            {loading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
            {insight ? 'Regenerate Analysis' : 'Analyze Trends'}
          </button>
        </div>

        {loading && (
           <div className="animate-pulse flex space-x-4">
             <div className="flex-1 space-y-4 py-1">
               <div className="h-4 bg-slate-700 rounded w-3/4"></div>
               <div className="space-y-2">
                 <div className="h-4 bg-slate-700 rounded"></div>
                 <div className="h-4 bg-slate-700 rounded w-5/6"></div>
               </div>
             </div>
           </div>
        )}

        {!loading && !insight && (
          <p className="text-slate-400 text-sm">
            Click the button above to have Gemini analyze your current performance metrics and keyword drivers.
          </p>
        )}

        {!loading && insight && (
          <div className="prose prose-invert max-w-none">
            <div className="text-slate-200 text-sm whitespace-pre-line leading-relaxed border-l-2 border-indigo-500 pl-4">
              {insight}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AIInsights;
