import React, { useRef, useState, useEffect } from 'react';
import { Upload, FileText, AlertCircle, Database } from 'lucide-react';
import { COLORS } from '../constants';

interface FileUploadProps {
  onDataLoaded: (csvText: string) => void;
  importError?: string | null;
}

const generateSampleData = () => {
  const today = new Date();
  const rows = [];
  rows.push('date,marketplace,asin,search_query,search_query_volume,asin_share_impressions,asin_share_clicks,asin_share_cart_adds,asin_share_purchases');
  
  const asins = ['B08X5X1234', 'B09Y6Y5678', 'B07Z4Z9012'];
  const marketplaces = ['US', 'UK', 'DE'];
  
  const keywordsMap: Record<string, string[]> = {
    'B08X5X1234': ['wireless headphones', 'bluetooth earbuds', 'noise cancelling headphones'],
    'B09Y6Y5678': ['running shoes men', 'sports sneakers', 'jogging shoes'],
    'B07Z4Z9012': ['gaming mouse', 'rgb mouse', 'pc accessories']
  };

  // Generate 45 days of data
  for (let i = 45; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(d.getDate() - i);
    const dateStr = d.toISOString().split('T')[0];
    
    asins.forEach((asin, aIdx) => {
      marketplaces.forEach((mp, mIdx) => {
        // Iterate through keywords for this ASIN
        const keywords = keywordsMap[asin] || ['generic keyword'];
        
        keywords.forEach((kw, kIdx) => {
            // Create some patterns
            let baseVol = mp === 'US' ? 50000 : (mp === 'UK' ? 15000 : 10000);
            
            // Adjust base volume by keyword popularity (first keyword is main one)
            baseVol = baseVol / (kIdx + 1);
    
            // Add seasonality/trend
            if (aIdx === 0) baseVol *= (1 + (45-i)/100); // Growing
            if (aIdx === 2) baseVol *= (1 + Math.sin(i/5) * 0.2); // Volatile
            
            const randomVar = 0.9 + Math.random() * 0.2;
            const vol = Math.floor(baseVol * randomVar);
            
            // Shares
            let imp = 15 + (Math.random() * 5); 
            if (mp === 'US') imp += 5;
            // Keywords 2 and 3 perform worse
            imp = imp / (kIdx + 1);
            
            // Funnel metrics
            const click = imp * (0.6 + Math.random() * 0.1);
            const cart = click * (0.4 + Math.random() * 0.1);
            const purch = cart * (0.8 + Math.random() * 0.1);
            
            rows.push(`${dateStr},${mp},${asin},${kw},${vol},${imp.toFixed(2)}%,${click.toFixed(2)}%,${cart.toFixed(2)}%,${purch.toFixed(2)}%`);
        });
      });
    });
  }
  return rows.join('\n');
};

const FileUpload: React.FC<FileUploadProps> = ({ onDataLoaded, importError }) => {
  const [error, setError] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Sync external errors to local state
  useEffect(() => {
    if (importError) {
      setError(importError);
    }
  }, [importError]);

  const handleFile = (file: File) => {
    // Relaxed validation: Check extension case-insensitive.
    if (!file.name.toLowerCase().endsWith('.csv')) {
      setError('Please upload a valid CSV file (must end with .csv).');
      return;
    }
    
    setError(null);
    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      onDataLoaded(text);
      
      // Reset input value so the same file can be selected again if needed
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    };
    reader.onerror = () => setError('Error reading file.');
    reader.readAsText(file);
  };

  const handleUseSampleData = () => {
    const sampleCsv = generateSampleData();
    onDataLoaded(sampleCsv);
  };

  const onDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const onDragLeave = () => setIsDragging(false);

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-[80vh] p-6">
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold text-white mb-2">Amazon Search Trends Dashboard</h1>
        <p className="text-pattern-muted">Upload your pattern performance CSV to get started.</p>
      </div>

      <div
        className={`w-full max-w-xl p-10 border-2 border-dashed rounded-xl transition-all duration-300 flex flex-col items-center justify-center cursor-pointer bg-pattern-card shadow-lg
          ${isDragging ? 'border-pattern-blue bg-slate-800' : 'border-pattern-border hover:border-pattern-blue hover:bg-slate-800'}`}
        onDragOver={onDragOver}
        onDragLeave={onDragLeave}
        onDrop={onDrop}
        onClick={() => fileInputRef.current?.click()}
      >
        <div className="bg-slate-800 p-4 rounded-full mb-4 border border-slate-700">
          <Upload className="w-8 h-8 text-pattern-blue" />
        </div>
        <p className="text-lg font-semibold text-white mb-1">Click to upload or drag and drop</p>
        <p className="text-sm text-pattern-muted mb-6">CSV files only</p>
        
        <input
          type="file"
          ref={fileInputRef}
          className="hidden"
          accept=".csv,text/csv,application/vnd.ms-excel"
          onChange={(e) => e.target.files && handleFile(e.target.files[0])}
        />
        
        <div className="flex items-center gap-2 text-xs text-pattern-muted border-t border-pattern-border pt-4 w-full justify-center mt-2">
          <FileText className="w-4 h-4" />
          <span>Supports standard Amazon Trends CSV formats</span>
        </div>
      </div>

      <div className="mt-6 flex flex-col items-center">
        <div className="relative flex py-2 items-center w-full max-w-md">
            <div className="flex-grow border-t border-pattern-border"></div>
            <span className="flex-shrink mx-4 text-pattern-muted text-sm">OR</span>
            <div className="flex-grow border-t border-pattern-border"></div>
        </div>
        
        <button 
            onClick={handleUseSampleData}
            className="mt-2 flex items-center gap-2 px-6 py-2 bg-pattern-card border border-pattern-border rounded-lg shadow-sm text-white font-medium hover:bg-slate-800 hover:border-pattern-blue hover:text-pattern-blue transition-all"
        >
            <Database className="w-4 h-4" />
            Load Sample Data
        </button>
      </div>

      {error && (
        <div className="mt-4 flex items-center gap-2 text-red-200 bg-red-900/30 border border-red-900 px-4 py-2 rounded-lg max-w-xl text-center">
          <AlertCircle className="w-5 h-5 flex-shrink-0" />
          <span className="text-sm">{error}</span>
        </div>
      )}
    </div>
  );
};

export default FileUpload;