import React, { useState } from 'react';
import { AggregatedDataPoint } from '../types';
import { METRICS } from '../constants';
import {
  ComposedChart, Line, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer
} from 'recharts';
import { Maximize2, Grid, Download, Check, Plus } from 'lucide-react';

interface MetricChartsProps {
  data: AggregatedDataPoint[];
}

const MetricCharts: React.FC<MetricChartsProps> = ({ data }) => {
  const [viewMode, setViewMode] = useState<'grid' | 'combined'>('combined');
  const [activeMetrics, setActiveMetrics] = useState<string[]>(
    METRICS.map(m => m.key as string)
  );

  const toggleMetric = (key: string) => {
    setActiveMetrics(prev => 
      prev.includes(key) 
        ? prev.filter(k => k !== key) 
        : [...prev, key]
    );
  };

  const downloadChart = (containerId: string, title: string) => {
    const container = document.getElementById(containerId);
    if (!container) return;
    
    const svg = container.querySelector('svg');
    if (!svg) return;

    const rect = svg.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;

    const clonedSvg = svg.cloneNode(true) as SVGElement;
    clonedSvg.setAttribute('width', width.toString());
    clonedSvg.setAttribute('height', height.toString());

    const serializer = new XMLSerializer();
    const svgString = serializer.serializeToString(clonedSvg);

    const canvas = document.createElement('canvas');
    const scale = 2;
    canvas.width = width * scale;
    canvas.height = height * scale;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.fillStyle = '#000000';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    const img = new Image();
    const blob = new Blob([svgString], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);

    img.onload = () => {
      ctx.drawImage(img, 0, 0, width * scale, height * scale);
      URL.revokeObjectURL(url);
      const link = document.createElement('a');
      link.download = `${title.replace(/\s+/g, '-').toLowerCase()}-${new Date().toISOString().split('T')[0]}.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();
    };

    img.src = url;
  };

  const axisStyle = {
    fontSize: 11,
    fill: '#475569', // Slate 600
    fontWeight: 500
  };

  const formatVolume = (val: number) => {
    if (val >= 1000000) return `${(val / 1000000).toFixed(0)}M`;
    if (val >= 1000) return `${(val / 1000).toFixed(0)}k`;
    return val;
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
  };

  return (
    <div className="mb-8">
      {/* Header with View Toggles */}
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold text-white tracking-tight">Performance Trends</h2>
        <div className="flex bg-slate-900 rounded-lg p-1 border border-slate-800">
          <button
            onClick={() => setViewMode('grid')}
            className={`p-2 rounded-md transition-all ${viewMode === 'grid' ? 'bg-slate-800 shadow text-pattern-blue' : 'text-slate-600 hover:text-white'}`}
            title="Grid View"
          >
            <Grid className="w-5 h-5" />
          </button>
          <button
            onClick={() => setViewMode('combined')}
            className={`p-2 rounded-md transition-all ${viewMode === 'combined' ? 'bg-slate-800 shadow text-pattern-blue' : 'text-slate-600 hover:text-white'}`}
            title="Combined View"
          >
            <Maximize2 className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="bg-pattern-card p-8 rounded-2xl shadow-2xl border border-slate-900 relative">
        {/* Top Section with Title and Metric Toggles */}
        <div className="flex flex-col lg:flex-row gap-8 mb-10">
          {/* Legend Area Header */}
          <div className="flex flex-col gap-1 min-w-[280px]">
            <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest">Combined View Analysis</h3>
            <p className="text-[10px] font-bold text-slate-600 uppercase tracking-tighter">Volume vs. Market Share</p>
          </div>

          {/* Metric Selector Chips */}
          <div className="flex flex-wrap gap-2 lg:flex-1">
            {METRICS.map(m => {
              const isActive = activeMetrics.includes(m.key as string);
              return (
                <button
                  key={m.key}
                  onClick={() => toggleMetric(m.key as string)}
                  style={{ borderColor: isActive ? m.color : '#1e293b' }}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-full border-2 text-[10px] font-bold transition-all ${
                    isActive 
                      ? 'bg-slate-900 text-white shadow-[0_0_10px_rgba(255,255,255,0.05)]' 
                      : 'bg-transparent text-slate-600 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <span className="w-2 h-2 rounded-full" style={{ backgroundColor: m.color }}></span>
                  {m.label}
                  {isActive ? <Check className="w-3 h-3" /> : <Plus className="w-3 h-3 opacity-40" />}
                </button>
              );
            })}
          </div>

          {/* Download Button */}
          <button
            onClick={() => downloadChart('chart-container-main', 'Performance Analysis')}
            className="p-2 self-start text-slate-600 hover:text-white transition-colors"
          >
            <Download className="w-5 h-5" />
          </button>
        </div>

        {/* Main Chart Area */}
        <div className="h-[550px] w-full" id="chart-container-main">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 40 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
              
              <XAxis 
                  dataKey="date" 
                  tick={axisStyle} 
                  tickLine={false}
                  axisLine={{ stroke: '#1e293b' }}
                  tickFormatter={formatDate}
                  dy={15}
                  label={{ value: 'Reporting Period', position: 'bottom', offset: 20, fill: '#475569', fontSize: 11, fontWeight: 700, letterSpacing: '1px' }}
              />
              
              <YAxis 
                  yAxisId="left" 
                  tick={axisStyle} 
                  tickLine={false}
                  axisLine={false}
                  tickFormatter={formatVolume}
                  label={{ value: 'Search Volume', angle: -90, position: 'insideLeft', offset: -10, fill: '#475569', fontSize: 11, fontWeight: 700 }}
              />
              
              <YAxis 
                  yAxisId="right" 
                  orientation="right" 
                  tick={axisStyle}
                  tickLine={false}
                  axisLine={false}
                  tickFormatter={(val) => `${val}%`}
                  label={{ value: 'Market Share (%)', angle: 90, position: 'insideRight', offset: -10, fill: '#475569', fontSize: 11, fontWeight: 700 }}
              />

              <Tooltip 
                labelFormatter={formatDate}
                contentStyle={{ backgroundColor: '#020617', border: '1px solid #1e293b', borderRadius: '8px', fontSize: '11px' }}
                itemStyle={{ padding: '2px 0' }}
              />

              {/* Legend */}
              <Legend 
                verticalAlign="top" 
                align="center" 
                height={50}
                iconType="plainline"
                iconSize={14}
                wrapperStyle={{ paddingTop: '0px', paddingBottom: '30px', textTransform: 'uppercase', fontSize: '10px', fontWeight: 800, letterSpacing: '1px' }}
              />

              {/* Render Search Volume as Bars */}
              {activeMetrics.includes('search_query_volume') && (
                <Bar 
                  yAxisId="left" 
                  dataKey="search_query_volume" 
                  name="SEARCH VOLUME" 
                  fill="#38BDF8" 
                  radius={[4, 4, 0, 0]} 
                  barSize={35}
                  opacity={0.6}
                />
              )}

              {/* Render Shares as Lines */}
              {METRICS.filter(m => m.format === 'percent' && activeMetrics.includes(m.key as string)).map((metric) => (
                <Line
                  key={metric.key}
                  yAxisId="right"
                  type="monotone"
                  dataKey={metric.key}
                  name={metric.label}
                  stroke={metric.color}
                  strokeWidth={3}
                  dot={{ r: 4, fill: metric.color, strokeWidth: 2, stroke: '#000' }}
                  activeDot={{ r: 7, fill: '#fff', stroke: metric.color, strokeWidth: 3 }}
                />
              ))}
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export default MetricCharts;