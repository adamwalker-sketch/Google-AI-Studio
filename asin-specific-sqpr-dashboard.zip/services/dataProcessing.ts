import { TrendDataPoint, FilterState, AggregatedDataPoint, SummaryStats, TimeGrain, KeywordStats } from '../types';
import { METRICS } from '../constants';

// --- CSV Parsing ---

export const parseCSV = (csvText: string): TrendDataPoint[] => {
  const cleanText = csvText.replace(/^\uFEFF/, '');
  const lines = cleanText.split(/\r?\n/);
  if (lines.length < 2) return [];

  const headers = lines[0].split(',').map(h => h.trim().toLowerCase());
  const data: TrendDataPoint[] = [];

  const getIndex = (key: string) => headers.findIndex(h => {
     const cleanHeader = h.replace(/_/g, ' ').replace(/\s+/g, ' ');
     const cleanKey = key.replace(/_/g, ' ').toLowerCase();
     return cleanHeader.includes(cleanKey);
  });
  
  let dateIdx = getIndex('date');
  let mpIdx = getIndex('marketplace');
  let asinIdx = getIndex('asin');
  
  let queryIdx = getIndex('search query');
  if (queryIdx === -1) queryIdx = getIndex('query');
  if (queryIdx === -1) queryIdx = getIndex('term');
  if (queryIdx === -1) queryIdx = getIndex('keyword');
  
  if (dateIdx === -1) dateIdx = 0;
  if (mpIdx === -1) {
    mpIdx = getIndex('market');
    if (mpIdx === -1) mpIdx = 1;
  }
  if (asinIdx === -1) {
    asinIdx = getIndex('product');
    if (asinIdx === -1) asinIdx = 2;
  }

  const metricIndices: Record<string, number> = {};
  METRICS.forEach((m, i) => {
    let idx = getIndex(m.key as string);
    if (idx === -1) idx = getIndex(m.label.toLowerCase());
    if (idx === -1) idx = 3 + i + (queryIdx !== -1 && queryIdx <= 3 ? 1 : 0);
    metricIndices[m.key as string] = idx;
  });

  for (let i = 1; i < lines.length; i++) {
    const line = lines[i];
    if (!line.trim()) continue;
    
    const values = line.split(','); 
    
    const point: Partial<TrendDataPoint> = {
      date: values[dateIdx]?.trim(),
      marketplace: values[mpIdx]?.trim(),
      asin: values[asinIdx]?.trim(),
      search_query: queryIdx !== -1 ? values[queryIdx]?.trim() : 'N/A'
    };

    METRICS.forEach(m => {
      const idx = metricIndices[m.key as string];
      const valStr = values[idx];
      if (!valStr) {
          point[m.key] = 0;
      } else {
        const val = parseFloat(valStr.replace('%', '').trim() || '0');
        if (isNaN(val)) {
          point[m.key] = 0; 
        } else {
          point[m.key] = val;
        }
      }
    });

    if (point.date && point.marketplace && point.asin) {
      data.push(point as TrendDataPoint);
    }
  }

  return data.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
};

// --- Filtering ---

export const filterData = (data: TrendDataPoint[], filters: FilterState): TrendDataPoint[] => {
  let searchRegex: RegExp | null = null;
  if (filters.searchQueryMode === 'regex' && filters.searchQueryFilter) {
    try {
      searchRegex = new RegExp(filters.searchQueryFilter, 'i');
    } catch (e) {
      console.error("Invalid Regex");
    }
  }

  return data.filter(item => {
    const itemDate = new Date(item.date);
    const start = new Date(filters.dateRange.start);
    const end = new Date(filters.dateRange.end);
    
    const inDateRange = itemDate >= start && itemDate <= end;
    const inMarketplace = filters.selectedMarketplace === 'All' || item.marketplace === filters.selectedMarketplace;
    const inAsin = filters.selectedAsins.length === 0 || filters.selectedAsins.includes(item.asin);
    
    // Direct Query Filter (Phrase, Exact, Regex)
    let inQuery = true;
    if (filters.searchQueryFilter) {
      const q = item.search_query.toLowerCase();
      const f = filters.searchQueryFilter.toLowerCase();
      
      if (filters.searchQueryMode === 'phrase') {
        inQuery = q.includes(f);
      } else if (filters.searchQueryMode === 'exact') {
        inQuery = q === f;
      } else if (filters.searchQueryMode === 'regex' && searchRegex) {
        inQuery = searchRegex.test(item.search_query);
      }
    }

    // Secondary Picker Filter (if any are explicitly selected)
    const inSelectedQuery = filters.selectedSearchQueries.length === 0 || filters.selectedSearchQueries.includes(item.search_query);

    return inDateRange && inMarketplace && inAsin && inQuery && inSelectedQuery;
  });
};

// --- Aggregation ---

const getPeriodKey = (dateStr: string, grain: TimeGrain): string => {
  const date = new Date(dateStr);
  if (grain === 'day') return dateStr;
  
  if (grain === 'week') {
    const day = date.getDay();
    const diff = date.getDate() - day + (day === 0 ? -6 : 1);
    const monday = new Date(date.setDate(diff));
    return monday.toISOString().split('T')[0];
  }

  if (grain === 'month') {
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-01`;
  }

  if (grain === 'quarter') {
    const q = Math.floor(date.getMonth() / 3);
    const month = q * 3;
    return `${date.getFullYear()}-${String(month + 1).padStart(2, '0')}-01`;
  }
  
  return dateStr;
};

export const aggregateData = (data: TrendDataPoint[], grain: TimeGrain): AggregatedDataPoint[] => {
  const groups: Record<string, any> = {};

  data.forEach(item => {
    const key = getPeriodKey(item.date, grain);
    const volume = item.search_query_volume || 0;
    
    if (!groups[key]) {
      groups[key] = { date: key, total_volume: 0 };
      METRICS.forEach(m => {
          groups[key][`${m.key}_sum`] = 0;
          groups[key][`${m.key}_weighted_sum`] = 0;
      });
    }
    
    groups[key].total_volume += volume;

    METRICS.forEach(m => {
       const val = item[m.key] as number;
       if (m.key === 'search_query_volume') {
           groups[key][`${m.key}_sum`] += val;
       } else {
           groups[key][`${m.key}_weighted_sum`] += (val * volume);
       }
    });
  });

  const result = Object.values(groups).map(group => {
    const point: AggregatedDataPoint = { date: group.date };
    const totalVol = group.total_volume;

    METRICS.forEach(m => {
      if (m.key === 'search_query_volume') {
        point[m.key as string] = group[`${m.key}_sum`];
      } else {
        point[m.key as string] = totalVol > 0 ? group[`${m.key}_weighted_sum`] / totalVol : 0;
      }
    });
    return point;
  });

  return result.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
};

export const aggregateByKeyword = (data: TrendDataPoint[]): KeywordStats[] => {
    const groups: Record<string, any> = {};
    
    data.forEach(item => {
        const key = item.search_query;
        if (key === 'N/A') return;
        const volume = item.search_query_volume || 0;

        if (!groups[key]) {
            groups[key] = { keyword: key, total_volume: 0 };
            METRICS.forEach(m => {
                groups[key][`${m.key}_sum`] = 0;
                groups[key][`${m.key}_weighted_sum`] = 0;
            });
        }
        
        groups[key].total_volume += volume;
        
        METRICS.forEach(m => {
             const val = item[m.key] as number;
             if (m.key === 'search_query_volume') {
                 groups[key][`${m.key}_sum`] += val;
             } else {
                 groups[key][`${m.key}_weighted_sum`] += (val * volume);
             }
        });
    });

    return Object.values(groups).map(g => {
        const stats: any = { keyword: g.keyword };
        const totalVol = g.total_volume;
        
        METRICS.forEach(m => {
            if (m.key === 'search_query_volume') {
                stats[m.key] = g[`${m.key}_sum`];
            } else {
                stats[m.key] = totalVol > 0 ? g[`${m.key}_weighted_sum`] / totalVol : 0;
            }
        });
        return stats as KeywordStats;
    }).sort((a, b) => b.search_query_volume - a.search_query_volume);
};

export const calculateSummaryStats = (currentData: TrendDataPoint[], previousData: TrendDataPoint[]): SummaryStats => {
  const stats: SummaryStats = {};

  const getWeightedValue = (data: TrendDataPoint[], metricKey: string): number => {
      if (metricKey === 'search_query_volume') {
          return data.reduce((sum, d) => sum + (d.search_query_volume || 0), 0);
      }

      let totalWeighted = 0;
      let totalVolume = 0;

      data.forEach(d => {
          const vol = d.search_query_volume || 0;
          const val = d[metricKey] as number;
          totalWeighted += (val * vol);
          totalVolume += vol;
      });

      return totalVolume > 0 ? totalWeighted / totalVolume : 0;
  };

  METRICS.forEach(m => {
    const currentVal = getWeightedValue(currentData, m.key as string);
    const prevVal = getWeightedValue(previousData, m.key as string);

    const change = prevVal === 0 ? (currentVal === 0 ? 0 : 100) : ((currentVal - prevVal) / prevVal) * 100;

    stats[m.key as string] = {
      current: currentVal,
      previous: prevVal,
      change: change
    };
  });

  return stats;
};