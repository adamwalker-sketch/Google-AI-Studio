import React, { useState, useEffect, useMemo } from 'react';
import FileUpload from './components/FileUpload';
import FilterBar from './components/FilterBar';
import SummaryCards from './components/SummaryCards';
import MetricCharts from './components/MetricCharts';
import DataTable from './components/DataTable';
import KeywordTable from './components/KeywordTable';
import AIInsights from './components/AIInsights';
import { parseCSV, filterData, aggregateData, calculateSummaryStats, aggregateByKeyword } from './services/dataProcessing';
import { getDashboardInsights, getKeywordContext } from './services/aiService';
import { TrendDataPoint, FilterState } from './types';
import { LayoutDashboard, RotateCcw } from 'lucide-react';

const App: React.FC = () => {
  const [rawData, setRawData] = useState<TrendDataPoint[]>([]);
  const [filters, setFilters] = useState<FilterState>({
    dateRange: { start: '', end: '' },
    timeGrain: 'month',
    marketplaces: [],
    selectedMarketplace: 'All',
    asins: [],
    selectedAsins: [],
    searchQueries: [],
    selectedSearchQueries: [],
    searchQueryFilter: '',
    searchQueryMode: 'phrase'
  });

  const [hasData, setHasData] = useState(false);
  const [importError, setImportError] = useState<string | null>(null);

  const handleDataLoaded = (csvText: string) => {
    setImportError(null);
    const data = parseCSV(csvText);
    if (data.length > 0) {
      const mps = Array.from(new Set(data.map(d => d.marketplace))).sort();
      const asins = Array.from(new Set(data.map(d => d.asin))).sort();
      const queries = Array.from(new Set(data.map(d => d.search_query))).filter(q => q !== 'N/A').sort();
      
      const dates = data.map(d => new Date(d.date).getTime()).sort((a,b) => a-b);
      const minDate = new Date(dates[0]);
      const maxDateObj = new Date(dates[dates.length - 1]);
      
      const thirtyDaysAgo = new Date(dates[dates.length - 1]);
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
      thirtyDaysAgo.setDate(1);
      
      const effectiveStart = thirtyDaysAgo.getTime() < minDate.getTime() 
        ? new Date(minDate.getFullYear(), minDate.getMonth(), 1) 
        : thirtyDaysAgo;

      const effectiveEnd = new Date(maxDateObj.getFullYear(), maxDateObj.getMonth() + 1, 0);

      const startDateStr = effectiveStart.toISOString().split('T')[0];
      const endDateStr = effectiveEnd.toISOString().split('T')[0];

      setRawData(data);
      setFilters({
        dateRange: { start: startDateStr, end: endDateStr },
        timeGrain: 'month',
        marketplaces: mps,
        selectedMarketplace: 'All',
        asins: asins,
        selectedAsins: [],
        searchQueries: queries,
        selectedSearchQueries: [],
        searchQueryFilter: '',
        searchQueryMode: 'phrase'
      });
      setHasData(true);
    } else {
      setImportError("We couldn't read valid data rows. Please ensure your file contains date, marketplace, and product information.");
    }
  };

  const { aggregatedData, summaryStats, keywordStats } = useMemo(() => {
    if (!hasData) return { filteredData: [], aggregatedData: [], summaryStats: {}, keywordStats: [] };

    const filtered = filterData(rawData, filters);
    const aggregated = aggregateData(filtered, filters.timeGrain);
    const keywords = aggregateByKeyword(filtered);

    const start = new Date(filters.dateRange.start);
    const end = new Date(filters.dateRange.end);
    const duration = end.getTime() - start.getTime();
    
    const prevEnd = new Date(start.getTime() - 86400000);
    const prevStart = new Date(prevEnd.getTime() - duration);
    
    const prevFilters: FilterState = {
        ...filters,
        dateRange: {
            start: prevStart.toISOString().split('T')[0],
            end: prevEnd.toISOString().split('T')[0]
        }
    };
    
    const prevFiltered = filterData(rawData, prevFilters);
    const stats = calculateSummaryStats(filtered, prevFiltered);

    return { filteredData: filtered, aggregatedData: aggregated, summaryStats: stats, keywordStats: keywords };
  }, [rawData, filters, hasData]);

  const resetData = () => {
    setHasData(false);
    setRawData([]);
    setImportError(null);
  };
  
  const handleGenerateInsights = async () => {
    return await getDashboardInsights(summaryStats, keywordStats);
  };
  
  const handleAnalyzeKeyword = async (keyword: string) => {
    return await getKeywordContext(keyword);
  };

  if (!hasData) {
    return (
        <div className="min-h-screen bg-pattern-dark">
             <FileUpload onDataLoaded={handleDataLoaded} importError={importError} />
        </div>
    )
  }

  return (
    <div className="min-h-screen bg-pattern-dark pb-20 text-pattern-text">
      <header className="bg-pattern-card border-b border-pattern-border sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <LayoutDashboard className="w-6 h-6 text-pattern-blue" />
            <h1 className="text-xl font-bold tracking-tight text-white">PatternTrends</h1>
          </div>
          <button 
            onClick={resetData}
            className="flex items-center gap-2 text-sm text-pattern-muted hover:text-white transition-colors"
          >
            <RotateCcw className="w-4 h-4" />
            Upload New File
          </button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        <FilterBar 
          filters={filters} 
          onFilterChange={setFilters} 
          availableMarketplaces={filters.marketplaces}
          availableAsins={filters.asins}
          availableSearchQueries={filters.searchQueries}
        />

        <AIInsights onGenerate={handleGenerateInsights} />

        <SummaryCards stats={summaryStats} />

        <MetricCharts data={aggregatedData} />
        
        {keywordStats.length > 0 && (
            <KeywordTable 
                data={keywordStats} 
                onAnalyzeKeyword={handleAnalyzeKeyword}
            />
        )}

        <DataTable data={aggregatedData} />

      </main>
    </div>
  );
};

export default App;