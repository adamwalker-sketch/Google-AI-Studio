# Standard Operating Procedure (SOP) - PatternTrends Dashboard

## 1. Overview
The PatternTrends Dashboard is a web-based analytics tool designed to visualize Amazon Search Query Performance (SQP) data. It allows users to upload CSV data, analyze performance trends (Impressions, Clicks, Cart Adds, Purchases), and gain AI-driven insights into consumer behavior.

## 2. Getting Started
### 2.1. Accessing the Tool
*   Open the application in a modern web browser.
*   Ensure you have a stable internet connection for AI features.

### 2.2. Data Requirements
*   **File Format:** CSV.
*   **Required Columns:** `Date`, `Marketplace`, `ASIN`, `Search Query`.
*   **Metric Columns:** `Search Query Volume`, `ASIN Share % (Impressions)`, etc.

## 3. Using the Dashboard
### 3.1. Filtering Data
Use the sticky **Filter Bar** at the top to refine the dataset:
*   **Search Filter:** Type into the search bar to filter all data by keywords.
    *   **Phrase:** Match any keyword containing the input text.
    *   **Exact:** Match only the exact keyword.
    *   **Regex:** Use Regular Expressions for complex pattern matching.
*   **Date Range:** Select start and end months.
*   **Products (ASINs):** Filter by specific product IDs using the dropdown.
*   **Aggregation:** Toggle between **Monthly** and **Quarterly** views.

### 3.2. Performance Overview (Summary Cards)
The top row cards show aggregated metrics for the selected period vs the previous equivalent period.

### 3.3. Visualizing Trends
Charts feature **Data Labels** for immediate value reading.
*   **Downloading Charts:** Click the **Download Icon** on any chart to save a high-res PNG with a black background.

### 3.4. AI Insights
Click **"Analyze Trends"** to get a Gemini-generated summary of performance drivers.

### 3.5. Keyword Analysis
*   **AI Context:** Click the **Robot Icon** for keyword-specific market context.
*   **CSV Export:** Use the **Download Icon** in the table header to export filtered data.

### 3.6. Detailed Data
Provides a time-series table of all metrics with a **CSV Download** option.

## 4. Troubleshooting
*   **Invalid Regex:** If the search bar border turns red, your regular expression syntax is incorrect.
*   **Missing Labels:** Ensure you have enough data points for the labels to render clearly without overlapping.