import { MetricConfig } from './types';

export const COLORS = {
  primary: '#38BDF8', // Pattern Blue (Sky 400)
  secondary: '#818CF8', // Purple-ish (Indigo 400)
  accent: '#2DD4BF', // Green (Teal 400)
  dark: '#020617', // Deep Dark
  text: '#F8FAFC',
  background: '#0F172A',
  charts: [
    '#38BDF8', // Search Volume (Blue)
    '#2DD4BF', // Impression Share (Teal)
    '#818CF8', // Click Share (Purple)
    '#FACC15', // Cart Add Share (Yellow)
    '#FB923C', // Purchase Share (Orange)
  ]
};

export const METRICS: MetricConfig[] = [
  { 
    key: 'search_query_volume', 
    label: 'SEARCH VOLUME', 
    color: COLORS.charts[0],
    format: 'number' 
  },
  { 
    key: 'asin_share_impressions', 
    label: 'IMPRESSION SHARE', 
    color: COLORS.charts[1],
    format: 'percent' 
  },
  { 
    key: 'asin_share_clicks', 
    label: 'CLICK SHARE', 
    color: COLORS.charts[2],
    format: 'percent' 
  },
  { 
    key: 'asin_share_cart_adds', 
    label: 'CART ADD SHARE', 
    color: COLORS.charts[3],
    format: 'percent' 
  },
  { 
    key: 'asin_share_purchases', 
    label: 'PURCHASE SHARE', 
    color: COLORS.charts[4],
    format: 'percent' 
  }
];

export const TIME_GRAINS = [
  { value: 'month', label: 'Monthly' },
  { value: 'quarter', label: 'Quarterly' },
];