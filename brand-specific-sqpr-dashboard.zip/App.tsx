import React, { useState, useEffect, useMemo } from 'react';
import FileUpload from './components/FileUpload';
import FilterBar from './components/FilterBar';
import SummaryCards from './components/SummaryCards';
import MetricCharts from './components/MetricCharts';
import DataTable from './components/DataTable';
import KeywordTable from './components/KeywordTable';
import AIInsights from './components/AIInsights';
import DeveloperDashboard from './components/DeveloperDashboard';
import { parseCSV, filterData, aggregateData, calculateSummaryStats, aggregateByKeyword } from './services/dataProcessing';
import { getDashboardInsights, getKeywordContext } from './services/aiService';
import { logEvent } from './services/eventLogger';
import { TrendDataPoint, FilterState } from './types';
import { LayoutDashboard, RotateCcw, ShieldCheck } from 'lucide-react';

const App: React.FC = () => {
  const [rawData, setRawData] = useState<TrendDataPoint[]>([]);
  const [showDevView, setShowDevView] = useState(false);
  const [filters, setFilters] = useState<FilterState>({
    dateRange: { start: '', end: '' },
    comparisonMode: 'prev_period',
    comparisonDateRange: { start: '', end: '' },
    timeGrain: 'month',
    marketplaces: [],
    selectedMarketplace: 'All',
    keywordFilter: '',
    keywordMatchMode: 'contains'
  });

  const [hasData, setHasData] = useState(false);
  const [importError, setImportError] = useState<string | null>(null);

  // Initial Data Processing upon Upload
  const handleDataLoaded = (csvText: string) => {
    setImportError(null);
    const data = parseCSV(csvText);
    if (data.length > 0) {
      logEvent('FILE_UPLOAD', { rowCount: data.length });
      // Extract unique filter options
      const mps = Array.from(new Set(data.map(d => d.marketplace))).sort();
      
      const minDateStr = data[0].date;
      const maxDateStr = data[data.length - 1].date;

      setRawData(data);
      setFilters({
        dateRange: { start: minDateStr, end: maxDateStr },
        comparisonMode: 'prev_period',
        comparisonDateRange: { start: '', end: '' },
        timeGrain: 'month', 
        marketplaces: mps,
        selectedMarketplace: 'All',
        keywordFilter: '',
        keywordMatchMode: 'contains'
      });
      setHasData(true);
    } else {
      setImportError("We couldn't read valid data rows. Please ensure your file contains date, marketplace, and query information.");
    }
  };

  useEffect(() => {
    logEvent('SESSION_START');
  }, []);

  const { filteredData, aggregatedData, summaryStats, keywordStats } = useMemo(() => {
    if (!hasData) return { filteredData: [], aggregatedData: [], summaryStats: {}, keywordStats: [] };

    const filtered = filterData(rawData, filters);
    const aggregated = aggregateData(filtered, filters.timeGrain);
    const keywords = aggregateByKeyword(filtered);

    let prevFiltered: TrendDataPoint[] = [];

    if (filters.comparisonMode !== 'none') {
        let prevStartStr = '';
        let prevEndStr = '';

        const start = new Date(filters.dateRange.start);
        const end = new Date(filters.dateRange.end);

        if (filters.comparisonMode === 'custom') {
            prevStartStr = filters.comparisonDateRange.start;
            prevEndStr = filters.comparisonDateRange.end;
        } else if (filters.comparisonMode === 'prev_year') {
            const ps = new Date(start);
            ps.setFullYear(ps.getFullYear() - 1);
            const pe = new Date(end);
            pe.setFullYear(pe.getFullYear() - 1);
            prevStartStr = ps.toISOString().split('T')[0];
            prevEndStr = pe.toISOString().split('T')[0];
        } else {
            const duration = end.getTime() - start.getTime();
            const prevEnd = new Date(start.getTime() - 86400000); 
            const prevStart = new Date(prevEnd.getTime() - duration);
            prevStartStr = prevStart.toISOString().split('T')[0];
            prevEndStr = prevEnd.toISOString().split('T')[0];
        }

        if (prevStartStr && prevEndStr) {
            const prevFilters: FilterState = {
                ...filters,
                dateRange: {
                    start: prevStartStr,
                    end: prevEndStr
                }
            };
            prevFiltered = filterData(rawData, prevFilters);
        }
    }
    
    const stats = calculateSummaryStats(filtered, prevFiltered);

    return { filteredData: filtered, aggregatedData: aggregated, summaryStats: stats, keywordStats: keywords };
  }, [rawData, filters, hasData]);

  const resetData = () => {
    setHasData(false);
    setRawData([]);
    setImportError(null);
  };
  
  const handleGenerateInsights = async (customPrompt?: string) => {
    logEvent('AI_INSIGHT', { type: 'DASHBOARD', prompt: customPrompt || 'DEFAULT' });
    return await getDashboardInsights(summaryStats, keywordStats, customPrompt);
  };
  
  const handleAnalyzeKeyword = async (keyword: string) => {
    logEvent('KEYWORD_ANALYZE', { keyword });
    return await getKeywordContext(keyword);
  };

  const toggleDevView = () => {
    logEvent('TOGGLE_DEV_VIEW', { newState: !showDevView });
    setShowDevView(!showDevView);
  };

  if (!hasData) {
    return (
        <div className="min-h-screen bg-pattern-dark">
             <FileUpload onDataLoaded={handleDataLoaded} importError={importError} />
        </div>
    )
  }

  return (
    <div className="min-h-screen bg-pattern-dark pb-20 text-pattern-text">
      <header className="bg-pattern-card border-b border-pattern-border sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <LayoutDashboard className="w-6 h-6 text-pattern-blue" />
            <h1 className="text-xl font-bold tracking-tight text-white">Brand-Specific SQPR Dashboard</h1>
          </div>
          <div className="flex items-center gap-4">
            <button 
              onClick={toggleDevView}
              className={`flex items-center gap-2 text-xs font-bold uppercase tracking-wider px-3 py-1.5 rounded-full transition-all border ${
                showDevView ? 'bg-indigo-600 border-indigo-500 text-white shadow-lg shadow-indigo-600/20' : 'text-slate-500 border-slate-700 hover:text-indigo-400 hover:border-indigo-800'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              {showDevView ? 'Dev Mode On' : 'Developer View'}
            </button>
            <button 
              onClick={resetData}
              className="flex items-center gap-2 text-sm text-pattern-muted hover:text-white transition-colors"
            >
              <RotateCcw className="w-4 h-4" />
              Reset
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {showDevView ? (
          <DeveloperDashboard />
        ) : (
          <>
            <FilterBar 
              filters={filters} 
              onFilterChange={setFilters} 
              availableMarketplaces={filters.marketplaces}
            />

            <AIInsights onGenerate={handleGenerateInsights} />

            <SummaryCards 
                stats={summaryStats} 
                showComparison={filters.comparisonMode !== 'none'}
            />

            <MetricCharts data={aggregatedData} />
            
            {keywordStats.length > 0 && (
                <KeywordTable 
                    data={keywordStats} 
                    onAnalyzeKeyword={handleAnalyzeKeyword}
                />
            )}

            <DataTable data={aggregatedData} />
          </>
        )}

      </main>
    </div>
  );
};

export default App;