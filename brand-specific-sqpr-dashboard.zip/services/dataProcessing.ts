import { TrendDataPoint, FilterState, AggregatedDataPoint, SummaryStats, TimeGrain, KeywordStats } from '../types';
import { METRICS } from '../constants';

// --- Helper for Date Formatting (MMM YYYY) ---
export const formatDateLabel = (dateStr: string): string => {
  if (!dateStr) return '';
  const parts = dateStr.split('-');
  if (parts.length < 2) return dateStr;
  
  const y = parseInt(parts[0], 10);
  const m = parseInt(parts[1], 10);
  
  // Array of month names
  const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  
  if (m >= 1 && m <= 12) {
      return `${monthNames[m - 1]} ${y}`;
  }
  return dateStr;
};

// --- CSV Parsing ---

export const parseCSV = (csvText: string): TrendDataPoint[] => {
  // Remove BOM if present (common in Excel CSV exports)
  const cleanText = csvText.replace(/^\uFEFF/, '');
  
  const lines = cleanText.split(/\r?\n/);
  if (lines.length < 2) return [];

  // Normalize headers: trim and lowercase for matching
  const headers = lines[0].split(',').map(h => h.trim());
  const lowerHeaders = headers.map(h => h.toLowerCase());
  
  const data: TrendDataPoint[] = [];

  // Explicit mapping for specific requested CSV headers to internal keys
  const explicitMappings: Record<string, string[]> = {
      'brand_share_impressions': ['impressions_brand_share', 'impressions brand share'],
      'brand_share_clicks': ['clicks_brand_share', 'clicks brand share'],
      'brand_share_cart_adds': ['cart_adds_brand_share', 'cart adds brand share'],
      'brand_share_purchases': ['purchases_brand_share', 'purchases brand share'],
      'purchases_price_median': ['purchases_price_median', 'purchases price median', 'median price'],
      'purchases_brand_price_median': ['purchases_brand_price_median', 'purchases brand price median', 'brand median price']
  };

  // Helper to find index
  const getIndex = (key: string, label?: string) => {
      // 1. Try explicit mappings first
      if (explicitMappings[key]) {
          const foundIdx = lowerHeaders.findIndex(h => 
              explicitMappings[key].some(mapping => h === mapping.toLowerCase())
          );
          if (foundIdx !== -1) return foundIdx;
      }

      // 2. Try partial matching on key (normalized)
      const cleanKey = key.replace(/_/g, ' ').toLowerCase();
      let idx = lowerHeaders.findIndex(h => {
          const cleanHeader = h.replace(/_/g, ' ').replace(/\s+/g, ' ');
          return cleanHeader.includes(cleanKey);
      });
      if (idx !== -1) return idx;

      // 3. Try partial matching on Label
      if (label) {
          const cleanLabel = label.toLowerCase();
          idx = lowerHeaders.findIndex(h => h.includes(cleanLabel));
          if (idx !== -1) return idx;
      }
      
      return -1;
  };
  
  let dateIdx = getIndex('date');
  let mpIdx = getIndex('marketplace');
  
  // Try to find keyword column
  let queryIdx = getIndex('search_query', 'search query');
  if (queryIdx === -1) queryIdx = getIndex('query');
  if (queryIdx === -1) queryIdx = getIndex('term');
  if (queryIdx === -1) queryIdx = getIndex('keyword');
  
  // FALLBACK: If specific headers are not found, assume standard order
  if (dateIdx === -1) dateIdx = 0;
  if (mpIdx === -1) {
    mpIdx = getIndex('market'); // Try partial "market"
    if (mpIdx === -1) mpIdx = 1;
  }
  
  // Metric indices
  const metricIndices: Record<string, number> = {};
  METRICS.forEach((m, i) => {
    let idx = getIndex(m.key as string, m.label);

    // Fallback: assume column position if not found by name
    if (idx === -1) idx = 3 + i;
    
    metricIndices[m.key as string] = idx;
  });

  for (let i = 1; i < lines.length; i++) {
    const line = lines[i];
    if (!line.trim()) continue;
    
    const values = line.split(','); 
    
    const rawDate = values[dateIdx]?.trim();
    let normalizedDate = '';

    // Normalize Date to YYYY-MM-DD
    if (rawDate) {
        if (/^\d{4}-\d{2}-\d{2}$/.test(rawDate)) {
             normalizedDate = rawDate;
        } else {
             const d = new Date(rawDate);
             if (!isNaN(d.getTime())) {
                let year = d.getFullYear();
                if (year < 100) year += 2000;
                const month = String(d.getMonth() + 1).padStart(2, '0');
                const day = String(d.getDate()).padStart(2, '0');
                normalizedDate = `${year}-${month}-${day}`;
             }
        }
    }

    if (!normalizedDate) continue;

    const point: Partial<TrendDataPoint> = {
      date: normalizedDate,
      marketplace: values[mpIdx]?.trim(),
      search_query: queryIdx !== -1 ? values[queryIdx]?.trim() : 'N/A'
    };

    METRICS.forEach(m => {
      const idx = metricIndices[m.key as string];
      const valStr = values[idx];
      if (!valStr) {
          point[m.key] = 0;
      } else {
        const val = parseFloat(valStr.replace('%', '').replace('$', '').trim() || '0');
        if (isNaN(val)) {
          point[m.key] = 0; 
        } else {
          point[m.key] = val;
        }
      }
    });

    if (point.date && point.marketplace) {
      data.push(point as TrendDataPoint);
    }
  }

  return data.sort((a, b) => a.date.localeCompare(b.date));
};

// --- Filtering ---

export const filterData = (data: TrendDataPoint[], filters: FilterState): TrendDataPoint[] => {
  const start = filters.dateRange.start;
  const end = filters.dateRange.end;

  return data.filter(item => {
    const inDateRange = item.date >= start && item.date <= end;
    const inMarketplace = filters.selectedMarketplace === 'All' || item.marketplace === filters.selectedMarketplace;
    
    let inQuery = true;
    if (filters.keywordFilter) {
      const q = filters.keywordFilter.trim();
      const term = item.search_query;
      
      if (filters.keywordMatchMode === 'exact') {
        inQuery = term.toLowerCase() === q.toLowerCase();
      } else if (filters.keywordMatchMode === 'regex') {
        try {
          const re = new RegExp(q, 'i');
          inQuery = re.test(term);
        } catch (e) {
          inQuery = false;
        }
      } else {
        inQuery = term.toLowerCase().includes(q.toLowerCase());
      }
    }

    return inDateRange && inMarketplace && inQuery;
  });
};

// --- Aggregation ---

const getPeriodKey = (dateStr: string, grain: TimeGrain): string => {
  const [y, m, d] = dateStr.split('-').map(Number);
  if (grain === 'day') return dateStr;
  if (grain === 'week') {
    const curr = new Date(y, m - 1, d);
    const day = curr.getDay();
    const diff = curr.getDate() - day + (day === 0 ? -6 : 1);
    const monday = new Date(curr.setDate(diff));
    return `${monday.getFullYear()}-${String(monday.getMonth() + 1).padStart(2, '0')}-${String(monday.getDate()).padStart(2, '0')}`;
  }
  if (grain === 'month') return `${y}-${String(m).padStart(2, '0')}-01`;
  if (grain === 'quarter') {
    const q = Math.floor((m - 1) / 3);
    return `${y}-${String(q * 3 + 1).padStart(2, '0')}-01`;
  }
  return dateStr;
};

export const aggregateData = (data: TrendDataPoint[], grain: TimeGrain): AggregatedDataPoint[] => {
  const groups: Record<string, any> = {};

  data.forEach(item => {
    const key = getPeriodKey(item.date, grain);
    const volume = item.search_query_volume || 0;
    
    if (!groups[key]) {
      groups[key] = { date: key, total_volume: 0 };
      METRICS.forEach(m => {
          groups[key][`${m.key}_sum`] = 0;
          groups[key][`${m.key}_weighted_sum`] = 0;
      });
    }
    
    groups[key].total_volume += volume;

    METRICS.forEach(m => {
       const val = item[m.key] as number;
       if (m.key === 'search_query_volume') {
           groups[key][`${m.key}_sum`] += val;
       } else {
           groups[key][`${m.key}_weighted_sum`] += (val * volume);
       }
    });
  });

  return Object.values(groups).map(group => {
    const point: AggregatedDataPoint = { date: group.date };
    const totalVol = group.total_volume;

    METRICS.forEach(m => {
      if (m.key === 'search_query_volume') {
        point[m.key as string] = group[`${m.key}_sum`];
      } else {
        point[m.key as string] = totalVol > 0 ? group[`${m.key}_weighted_sum`] / totalVol : 0;
      }
    });
    return point;
  }).sort((a, b) => a.date.localeCompare(b.date));
};

// --- Keyword Aggregation ---

export const aggregateByKeyword = (data: TrendDataPoint[]): KeywordStats[] => {
    const groups: Record<string, any> = {};
    
    data.forEach(item => {
        const key = item.search_query;
        if (key === 'N/A') return;
        const volume = item.search_query_volume || 0;

        if (!groups[key]) {
            groups[key] = { keyword: key, total_volume: 0 };
            METRICS.forEach(m => {
                groups[key][`${m.key}_sum`] = 0;
                groups[key][`${m.key}_weighted_sum`] = 0;
            });
        }
        
        groups[key].total_volume += volume;
        
        METRICS.forEach(m => {
             const val = item[m.key] as number;
             if (m.key === 'search_query_volume') {
                 groups[key][`${m.key}_sum`] += val;
             } else {
                 groups[key][`${m.key}_weighted_sum`] += (val * volume);
             }
        });
    });

    return Object.values(groups).map(g => {
        const stats: any = { keyword: g.keyword };
        const totalVol = g.total_volume;
        
        METRICS.forEach(m => {
            if (m.key === 'search_query_volume') {
                stats[m.key] = g[`${m.key}_sum`];
            } else {
                stats[m.key] = totalVol > 0 ? g[`${m.key}_weighted_sum`] / totalVol : 0;
            }
        });
        return stats as KeywordStats;
    }).sort((a, b) => b.search_query_volume - a.search_query_volume);
};

// --- Summary Stats with Comparison ---

export const calculateSummaryStats = (currentData: TrendDataPoint[], previousData: TrendDataPoint[]): SummaryStats => {
  const stats: SummaryStats = {};

  const getWeightedValue = (data: TrendDataPoint[], metricKey: string): number => {
      if (metricKey === 'search_query_volume') {
          return data.reduce((sum, d) => sum + (d.search_query_volume || 0), 0);
      }
      let totalWeighted = 0;
      let totalVolume = 0;
      data.forEach(d => {
          const vol = d.search_query_volume || 0;
          const val = d[metricKey] as number;
          totalWeighted += (val * vol);
          totalVolume += vol;
      });
      return totalVolume > 0 ? totalWeighted / totalVolume : 0;
  };

  METRICS.forEach(m => {
    const currentVal = getWeightedValue(currentData, m.key as string);
    const prevVal = getWeightedValue(previousData, m.key as string);
    const change = prevVal === 0 ? (currentVal === 0 ? 0 : 100) : ((currentVal - prevVal) / prevVal) * 100;
    stats[m.key as string] = { current: currentVal, previous: prevVal, change };
  });

  return stats;
};