import { AppEvent, EventType } from '../types';

const STORAGE_KEY = 'sqpr_usage_logs';

export const logEvent = (type: EventType, metadata?: Record<string, any>) => {
  const event: AppEvent = {
    id: crypto.randomUUID(),
    timestamp: new Date().toISOString(),
    type,
    metadata,
    userAgent: navigator.userAgent
  };

  try {
    const existingLogs = getLogs();
    const updatedLogs = [event, ...existingLogs].slice(0, 500); // Keep last 500 events
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedLogs));
    
    // In a real app, you would send this to an API:
    // fetch('/api/telemetry', { method: 'POST', body: JSON.stringify(event) });
    console.debug(`[Telemetry] ${type}`, metadata);
  } catch (e) {
    console.error('Failed to log event', e);
  }
};

export const getLogs = (): AppEvent[] => {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : [];
  } catch (e) {
    return [];
  }
};

export const clearLogs = () => {
  localStorage.removeItem(STORAGE_KEY);
};