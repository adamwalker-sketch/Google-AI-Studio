
import { GoogleGenAI } from "@google/genai";
import { SummaryStats, KeywordStats } from '../types';

// Initialize the client
// API Key is guaranteed to be in process.env.API_KEY
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getDashboardInsights = async (
  stats: SummaryStats, 
  topKeywords: KeywordStats[],
  customInstruction?: string
): Promise<string> => {
  try {
    const metricsSummary = Object.entries(stats)
      .map(([key, val]) => `${key}: ${val.current.toFixed(2)} (Change: ${val.change.toFixed(1)}%)`)
      .join('\n');

    const keywordsSummary = topKeywords
      .slice(0, 5)
      .map(k => `- ${k.keyword} (Vol: ${k.search_query_volume})`)
      .join('\n');

    let instruction = `
      Provide a concise executive summary (max 3 bullet points) highlighting the most important positive or negative trends and potential reasons based on the data. 
      Do not use markdown formatting like bolding, just plain text with bullet points.
    `;

    if (customInstruction && customInstruction.trim() !== '') {
        instruction = `
            Answer the following user query based on the provided data analysis:
            "${customInstruction}"

            If the data provided doesn't directly answer the question, provide the best possible hypothesis based on the trends or state what is missing.
        `;
    }

    const prompt = `
      You are an expert Amazon e-commerce analyst. 
      
      Here is the performance data for the selected period compared to the previous period:
      
      Metrics:
      ${metricsSummary}

      Top performing search terms:
      ${keywordsSummary}

      ${instruction}
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
      },
    });

    return response.text || "Unable to generate insights at this time.";
  } catch (error) {
    console.error("Error generating insights:", error);
    return "Error connecting to AI service.";
  }
};

export const getKeywordContext = async (keyword: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Explain why consumers might be searching for "${keyword}" right now. Focus on seasonality, specific product releases, or viral trends. Keep it to 1-2 sentences.`,
      config: {
        tools: [{ googleSearch: {} }],
      },
    });

    // Check for grounding metadata to ensure search was used, though we just return text here.
    return response.text || "No context available.";
  } catch (error) {
    console.error("Error fetching keyword context:", error);
    return "Unable to fetch context.";
  }
};