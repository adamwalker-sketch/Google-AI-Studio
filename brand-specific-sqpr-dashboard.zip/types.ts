export interface TrendDataPoint {
  date: string; // YYYY-MM-DD
  marketplace: string;
  search_query: string;
  search_query_volume: number;
  brand_share_impressions: number;
  brand_share_clicks: number;
  brand_share_cart_adds: number;
  brand_share_purchases: number;
  purchases_price_median?: number;
  purchases_brand_price_median?: number;
  [key: string]: string | number | undefined;
}

export interface MetricConfig {
  key: keyof TrendDataPoint;
  label: string;
  color: string;
  format: 'number' | 'percent' | 'currency';
}

export type TimeGrain = 'day' | 'week' | 'month' | 'quarter';

export type KeywordMatchMode = 'contains' | 'exact' | 'regex';

export type ComparisonMode = 'none' | 'prev_period' | 'prev_year' | 'custom';

export interface FilterState {
  dateRange: {
    start: string;
    end: string;
  };
  comparisonMode: ComparisonMode;
  comparisonDateRange: {
    start: string;
    end: string;
  };
  timeGrain: TimeGrain;
  marketplaces: string[];
  selectedMarketplace: string;
  keywordFilter: string;
  keywordMatchMode: KeywordMatchMode;
}

export interface AggregatedDataPoint {
  date: string; // The start date of the period
  [key: string]: number | string;
}

export interface KeywordStats {
  keyword: string;
  search_query_volume: number;
  brand_share_impressions: number;
  brand_share_clicks: number;
  brand_share_cart_adds: number;
  brand_share_purchases: number;
  purchases_price_median?: number;
  purchases_brand_price_median?: number;
  [key: string]: string | number | undefined;
}

export interface SummaryMetric {
  current: number;
  previous: number;
  change: number;
}

export interface SummaryStats {
  [key: string]: SummaryMetric;
}

// Telemetry Types
export type EventType = 'SESSION_START' | 'FILE_UPLOAD' | 'AI_INSIGHT' | 'EXPORT_CSV' | 'DOWNLOAD_PNG' | 'KEYWORD_ANALYZE' | 'TOGGLE_DEV_VIEW';

export interface AppEvent {
  id: string;
  timestamp: string;
  type: EventType;
  metadata?: Record<string, any>;
  userAgent: string;
}