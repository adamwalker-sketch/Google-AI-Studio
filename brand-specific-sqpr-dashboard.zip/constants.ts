import { MetricConfig } from './types';

export const COLORS = {
  primary: '#38BDF8', // Pattern Blue (Sky 400)
  secondary: '#818CF8', // Purple-ish (Indigo 400)
  accent: '#2DD4BF', // Green (Teal 400)
  dark: '#020617', // Deep Dark
  text: '#F8FAFC',
  background: '#0F172A',
  charts: [
    '#38BDF8', // Blue
    '#2DD4BF', // Teal
    '#818CF8', // Purple
    '#FACC15', // Yellow
    '#FB923C', // Orange
    '#F472B6', // Pink
    '#A78BFA', // Violet
    '#34D399', // Emerald
  ]
};

export const METRICS: MetricConfig[] = [
  { 
    key: 'search_query_volume', 
    label: 'Search Volume', 
    color: COLORS.charts[0],
    format: 'number' 
  },
  { 
    key: 'brand_share_impressions', 
    label: 'Impression Share', 
    color: COLORS.charts[1],
    format: 'percent' 
  },
  { 
    key: 'brand_share_clicks', 
    label: 'Click Share', 
    color: COLORS.charts[2],
    format: 'percent' 
  },
  { 
    key: 'brand_share_cart_adds', 
    label: 'Cart Add Share', 
    color: COLORS.charts[3],
    format: 'percent' 
  },
  { 
    key: 'brand_share_purchases', 
    label: 'Purchase Share', 
    color: COLORS.charts[4],
    format: 'percent' 
  },
  { 
    key: 'purchases_price_median', 
    label: 'Marketplace Median Price', 
    color: COLORS.charts[5],
    format: 'currency' 
  },
  { 
    key: 'purchases_brand_price_median', 
    label: 'Brand Median Price', 
    color: COLORS.charts[6],
    format: 'currency' 
  },
];

export const TIME_GRAINS = [
  { value: 'month', label: 'Monthly' },
  { value: 'quarter', label: 'Quarterly' },
];