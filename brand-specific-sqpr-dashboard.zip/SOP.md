
# Standard Operating Procedure (SOP) - BrandTrends Dashboard

## 1. Overview
The BrandTrends Dashboard is a web-based analytics tool designed to visualize Amazon Brand Search Query Performance (SQP) data. It allows users to upload Brand-level CSV data, analyze performance trends (Impressions, Clicks, Cart Adds, Purchases), and gain AI-driven insights into consumer behavior.

## 2. Getting Started
### 2.1. Accessing the Tool
*   Open the application in a modern web browser (Chrome, Edge, Firefox).
*   Ensure you have a stable internet connection for AI features.

### 2.2. Data Requirements
*   **File Format:** CSV (Comma Separated Values).
*   **Required Columns:** `Date` (reporting date), `Marketplace` (e.g., US, UK), `Search Query` (Keyword).
*   **Metric Columns:** `Search Query Volume`, `Brand Share % (Impressions)`, `Brand Share % (Clicks)`, `Brand Share % (Cart Adds)`, `Brand Share % (Purchases)`.
*   *Note:* The tool supports flexible header matching (e.g., "Impression Share" or "Brand Share").

### 2.3. Uploading Data
1.  On the landing screen, click the **"Click to upload"** area or drag and drop your CSV file.
2.  Alternatively, click **"Load Sample Data"** to explore the tool with dummy data.
3.  If successful, the dashboard will load. If an error occurs, check the file format against section 2.2.

## 3. Using the Dashboard
### 3.1. Filtering Data
Use the sticky **Filter Bar** at the top to refine the dataset:
*   **Date Range:** Select start and end months. The tool defaults to the most recent month of data.
*   **Aggregation:** Toggle between **Monthly** and **Quarterly** views for trend lines.
*   **Search Terms:** Search for and select specific keywords. Supports text match ("Contains"), Exact match, and Regex.

### 3.2. Performance Overview (Summary Cards)
The top row cards show aggregated metrics for the selected period:
*   **Volume:** Total Search Volume.
*   **Shares:** Weighted average market share for Impressions, Clicks, Cart Adds, and Purchases.
*   **Comparison:** Green/Red indicators show percentage change vs. the previous period of the same length.

### 3.3. Visualizing Trends
*   **Grid View:** Displays individual line charts for each metric.
*   **Combined View:** Overlays all metrics on a single chart (Volume on left axis, Shares on right axis).
*   **Downloading Charts:** Click the **Download Icon** (arrow pointing down) in the top-right corner of any chart to save it as a high-resolution PNG.

### 3.4. AI Insights
*   Click **"Analyze Trends"** in the "Gemini Intelligence" section.
*   The AI will generate an executive summary highlighting key growth areas or declines based on the current data view.

### 3.5. Keyword Analysis
*   Scroll to the **Keyword Performance** table.
*   **Sorting & Filtering:** Use the column headers to sort or click the filter icon to search within specific columns.
*   **Context:** Click the **Robot Icon** next to any keyword row to get AI-driven context about seasonality or trends.
*   **Exporting:** Click the **Download Icon** in the table header to export the currently filtered keyword list (including generated AI context) as a CSV file.

### 3.6. Detailed Data
*   Scroll to the bottom **Detailed Data** table to see the raw aggregated numbers based on your time selection (Monthly/Quarterly).
*   **Exporting:** Click the **Download Icon** in the table header to export this time-series data as a CSV file.

## 4. Troubleshooting
*   **"We couldn't read valid data rows":** Ensure your CSV has headers and follows the standard Amazon SQP report format.
*   **AI features not working:** Check your internet connection. AI quotas may apply.
*   **Charts look empty:** Ensure your filters (Date, Marketplace) match the data range in your CSV.