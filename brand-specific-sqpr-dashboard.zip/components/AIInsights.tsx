import React, { useState } from 'react';
import { Sparkles, RefreshCw, MessageSquare } from 'lucide-react';

interface AIInsightsProps {
  onGenerate: (customPrompt?: string) => Promise<string>;
}

const AIInsights: React.FC<AIInsightsProps> = ({ onGenerate }) => {
  const [insight, setInsight] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [customPrompt, setCustomPrompt] = useState('');

  const handleGenerate = async () => {
    setLoading(true);
    const result = await onGenerate(customPrompt);
    setInsight(result);
    setLoading(false);
  };

  return (
    <div className="bg-gradient-to-r from-slate-900 to-slate-800 rounded-xl shadow-lg border border-indigo-500/30 p-6 mb-6 relative overflow-hidden">
      <div className="absolute top-0 right-0 p-4 opacity-10">
        <Sparkles className="w-24 h-24 text-indigo-400" />
      </div>
      
      <div className="relative z-10">
        <div className="flex items-center gap-2 mb-4">
            <Sparkles className="w-5 h-5 text-indigo-400" />
            <h2 className="text-lg font-bold text-white">Gemini Intelligence</h2>
        </div>

        <div className="mb-4">
            <label className="text-xs font-semibold text-pattern-muted uppercase flex items-center gap-1 mb-2">
                <MessageSquare className="w-3 h-3" /> Custom Query (Optional)
            </label>
            <textarea
                className="w-full bg-slate-950/50 border border-pattern-border rounded-lg p-3 text-sm text-white placeholder-slate-500 focus:ring-1 focus:ring-indigo-500 outline-none transition-all resize-none"
                rows={2}
                placeholder="Ask specific questions about the data (e.g., 'Why did conversion drop in November?', 'Summarize the top 3 trends')..."
                value={customPrompt}
                onChange={(e) => setCustomPrompt(e.target.value)}
            />
        </div>

        <div className="flex items-center justify-between mb-4">
          <button
            onClick={handleGenerate}
            disabled={loading}
            className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-medium rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-indigo-500/20"
          >
            {loading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
            {insight ? 'Regenerate Analysis' : 'Analyze Data'}
          </button>
        </div>

        {loading && (
           <div className="animate-pulse flex space-x-4">
             <div className="flex-1 space-y-4 py-1">
               <div className="h-4 bg-slate-700 rounded w-3/4"></div>
               <div className="space-y-2">
                 <div className="h-4 bg-slate-700 rounded"></div>
                 <div className="h-4 bg-slate-700 rounded w-5/6"></div>
               </div>
             </div>
           </div>
        )}

        {!loading && insight && (
          <div className="prose prose-invert max-w-none mt-4 bg-slate-950/30 p-4 rounded-lg border border-indigo-500/20">
            <div className="text-slate-200 text-sm whitespace-pre-line leading-relaxed">
              {insight}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AIInsights;