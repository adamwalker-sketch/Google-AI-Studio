import React, { useState, useEffect } from 'react';
import { getLogs, clearLogs } from '../services/eventLogger';
import { AppEvent } from '../types';
import { 
  Terminal, Trash2, Download, RefreshCcw, ShieldCheck, 
  Activity, BarChart3, Fingerprint, Clock, Search
} from 'lucide-react';

const DeveloperDashboard: React.FC = () => {
  const [logs, setLogs] = useState<AppEvent[]>([]);
  const [filter, setFilter] = useState('');

  const refresh = () => {
    setLogs(getLogs());
  };

  useEffect(() => {
    refresh();
  }, []);

  const handleClear = () => {
    if (confirm('Are you sure you want to delete all usage history?')) {
      clearLogs();
      refresh();
    }
  };

  const handleDownload = () => {
    const dataStr = JSON.stringify(logs, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `usage_logs_${new Date().toISOString().split('T')[0]}.json`;
    link.click();
  };

  const stats = {
    total: logs.length,
    uploads: logs.filter(l => l.type === 'FILE_UPLOAD').length,
    ai: logs.filter(l => l.type === 'AI_INSIGHT').length,
    exports: logs.filter(l => l.type === 'EXPORT_CSV' || l.type === 'DOWNLOAD_PNG').length,
  };

  const filteredLogs = logs.filter(l => 
    l.type.toLowerCase().includes(filter.toLowerCase()) || 
    JSON.stringify(l.metadata || {}).toLowerCase().includes(filter.toLowerCase())
  );

  return (
    <div className="bg-[#020617] min-h-[80vh] p-6 rounded-2xl border border-slate-800 shadow-2xl overflow-hidden flex flex-col">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div className="flex items-center gap-3">
          <div className="bg-indigo-500/20 p-2 rounded-lg">
            <ShieldCheck className="w-6 h-6 text-indigo-400" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white">Developer Usage Dashboard</h2>
            <p className="text-xs text-slate-400">Internal telemetry and interaction auditing</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button 
            onClick={refresh}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg transition-colors"
            title="Refresh Logs"
          >
            <RefreshCcw className="w-4 h-4" />
          </button>
          <button 
            onClick={handleDownload}
            className="flex items-center gap-2 px-3 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-medium rounded-lg transition-colors"
          >
            <Download className="w-4 h-4" />
            Export JSON
          </button>
          <button 
            onClick={handleClear}
            className="p-2 bg-red-900/20 hover:bg-red-900/40 text-red-400 border border-red-900/50 rounded-lg transition-colors"
            title="Clear All Logs"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <div className="bg-slate-900/50 p-4 rounded-xl border border-slate-800">
          <Activity className="w-4 h-4 text-indigo-400 mb-2" />
          <div className="text-2xl font-bold text-white">{stats.total}</div>
          <div className="text-[10px] text-slate-500 uppercase font-bold tracking-wider">Total Actions</div>
        </div>
        <div className="bg-slate-900/50 p-4 rounded-xl border border-slate-800">
          <BarChart3 className="w-4 h-4 text-emerald-400 mb-2" />
          <div className="text-2xl font-bold text-white">{stats.uploads}</div>
          <div className="text-[10px] text-slate-500 uppercase font-bold tracking-wider">Data Ingests</div>
        </div>
        <div className="bg-slate-900/50 p-4 rounded-xl border border-slate-800">
          <Terminal className="w-4 h-4 text-amber-400 mb-2" />
          <div className="text-2xl font-bold text-white">{stats.ai}</div>
          <div className="text-[10px] text-slate-500 uppercase font-bold tracking-wider">AI Operations</div>
        </div>
        <div className="bg-slate-900/50 p-4 rounded-xl border border-slate-800">
          <Clock className="w-4 h-4 text-purple-400 mb-2" />
          <div className="text-2xl font-bold text-white">{stats.exports}</div>
          <div className="text-[10px] text-slate-500 uppercase font-bold tracking-wider">Data Exports</div>
        </div>
      </div>

      {/* Log Section */}
      <div className="flex-grow flex flex-col min-h-0 bg-slate-950/50 border border-slate-800 rounded-xl overflow-hidden">
        <div className="p-3 border-b border-slate-800 bg-slate-900/30 flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-400 uppercase tracking-widest">
            <Clock className="w-3 h-3" /> Audit Log
          </div>
          <div className="relative">
            <Search className="w-3 h-3 absolute left-2 top-1/2 -translate-y-1/2 text-slate-500" />
            <input 
              type="text" 
              placeholder="Search events..." 
              className="bg-slate-900 border border-slate-700 rounded-md py-1 pl-7 pr-3 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500 w-48"
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
            />
          </div>
        </div>
        
        <div className="overflow-y-auto flex-grow scrollbar-thin scrollbar-thumb-slate-700">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-900/80 sticky top-0 text-slate-500 border-b border-slate-800">
              <tr>
                <th className="px-4 py-2 font-medium">Timestamp</th>
                <th className="px-4 py-2 font-medium">Event Type</th>
                <th className="px-4 py-2 font-medium">Metadata</th>
                <th className="px-4 py-2 font-medium">Context</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/50">
              {filteredLogs.map((log) => (
                <tr key={log.id} className="hover:bg-indigo-500/5 transition-colors">
                  <td className="px-4 py-3 text-slate-400 whitespace-nowrap font-mono">
                    {new Date(log.timestamp).toLocaleTimeString()}
                    <span className="opacity-40 ml-2">{new Date(log.timestamp).toLocaleDateString()}</span>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      log.type === 'FILE_UPLOAD' ? 'bg-emerald-900/30 text-emerald-400' :
                      log.type === 'AI_INSIGHT' ? 'bg-amber-900/30 text-amber-400' :
                      log.type === 'SESSION_START' ? 'bg-blue-900/30 text-blue-400' :
                      'bg-slate-800 text-slate-300'
                    }`}>
                      {log.type}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-slate-300 max-w-md">
                    <div className="truncate font-mono text-[10px]">
                      {JSON.stringify(log.metadata || {})}
                    </div>
                  </td>
                  <td className="px-4 py-3 text-slate-500 italic max-w-xs truncate" title={log.userAgent}>
                    {log.userAgent.split(')')[0].split('(')[1] || 'Unknown Client'}
                  </td>
                </tr>
              ))}
              {filteredLogs.length === 0 && (
                <tr>
                  <td colSpan={4} className="px-4 py-12 text-center text-slate-600">
                    No matching log events found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
      
      <div className="mt-4 p-3 bg-indigo-900/10 border border-indigo-900/20 rounded-lg flex items-start gap-2">
        <Fingerprint className="w-4 h-4 text-indigo-400 flex-shrink-0 mt-0.5" />
        <p className="text-[10px] text-slate-400 leading-relaxed">
          <strong className="text-indigo-400 uppercase">Note:</strong> These logs are stored locally in the browser. To track global performance across all users, connect the <code className="text-white">eventLogger</code> service to a remote monitoring endpoint.
        </p>
      </div>
    </div>
  );
};

export default DeveloperDashboard;