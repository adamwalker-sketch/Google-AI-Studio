import React from 'react';
import { FilterState, KeywordMatchMode, ComparisonMode } from '../types';
import { TIME_GRAINS } from '../constants';
import { Calendar, Search, X, BarChart, ArrowRightLeft } from 'lucide-react';

interface FilterBarProps {
  filters: FilterState;
  onFilterChange: (newFilters: FilterState) => void;
  availableMarketplaces: string[];
}

const FilterBar: React.FC<FilterBarProps> = ({ 
    filters, 
    onFilterChange, 
    availableMarketplaces
}) => {

  const handleMonthChange = (type: 'start' | 'end', value: string, isComparison: boolean = false) => {
    if (!value) return;
    
    // value is YYYY-MM
    let dateStr = '';
    const [y, m] = value.split('-').map(Number);
    
    // Logic: Start sets to 1st, End sets to last day of month
    if (type === 'start') {
        dateStr = `${value}-01`;
    } else {
        const lastDay = new Date(y, m, 0).getDate();
        dateStr = `${value}-${String(lastDay).padStart(2, '0')}`;
    }
    
    if (isComparison) {
        onFilterChange({
            ...filters,
            comparisonDateRange: { ...filters.comparisonDateRange, [type]: dateStr }
        });
    } else {
        onFilterChange({
            ...filters,
            dateRange: { ...filters.dateRange, [type]: dateStr }
        });
    }
  };

  return (
    <div className="bg-pattern-card p-4 rounded-xl shadow-lg border border-pattern-border mb-6 sticky top-[64px] z-20">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-4">
        
        {/* Date Range (3 cols) */}
        <div className="flex flex-col gap-1 lg:col-span-3">
          <label className="text-xs font-semibold text-pattern-muted uppercase flex items-center gap-1">
            <Calendar className="w-3 h-3" /> Date Range
          </label>
          <div className="flex flex-col sm:flex-row gap-2">
            <input
              type="month"
              className="bg-pattern-input border border-pattern-border rounded px-2 py-1.5 text-xs w-full focus:ring-1 focus:ring-pattern-blue outline-none text-white placeholder-gray-500"
              value={filters.dateRange.start.slice(0, 7)}
              onChange={(e) => handleMonthChange('start', e.target.value)}
            />
            <input
              type="month"
              className="bg-pattern-input border border-pattern-border rounded px-2 py-1.5 text-xs w-full focus:ring-1 focus:ring-pattern-blue outline-none text-white placeholder-gray-500"
              value={filters.dateRange.end.slice(0, 7)}
              onChange={(e) => handleMonthChange('end', e.target.value)}
            />
          </div>
        </div>

        {/* Comparison (3 cols) */}
        <div className="flex flex-col gap-1 lg:col-span-3">
            <label className="text-xs font-semibold text-pattern-muted uppercase flex items-center gap-1">
                <ArrowRightLeft className="w-3 h-3" /> Compare To
            </label>
            <div className="flex flex-col sm:flex-row gap-2">
                <select
                    className="bg-pattern-input border border-pattern-border rounded px-2 py-1.5 text-xs w-full focus:ring-1 focus:ring-pattern-blue outline-none text-white"
                    value={filters.comparisonMode}
                    onChange={(e) => onFilterChange({ ...filters, comparisonMode: e.target.value as ComparisonMode })}
                >
                    <option value="none">No Comparison</option>
                    <option value="prev_period">Previous Period</option>
                    <option value="prev_year">Previous Year</option>
                    <option value="custom">Custom Range</option>
                </select>
                
                {filters.comparisonMode === 'custom' && (
                     <div className="flex gap-1 w-full">
                        <input
                            type="month"
                            className="bg-pattern-input border border-pattern-border rounded px-1 py-1.5 text-xs w-1/2 focus:ring-1 focus:ring-pattern-blue outline-none text-white"
                            value={filters.comparisonDateRange.start.slice(0, 7)}
                            onChange={(e) => handleMonthChange('start', e.target.value, true)}
                        />
                        <input
                            type="month"
                            className="bg-pattern-input border border-pattern-border rounded px-1 py-1.5 text-xs w-1/2 focus:ring-1 focus:ring-pattern-blue outline-none text-white"
                            value={filters.comparisonDateRange.end.slice(0, 7)}
                            onChange={(e) => handleMonthChange('end', e.target.value, true)}
                        />
                    </div>
                )}
            </div>
        </div>

        {/* Aggregation (2 cols) */}
        <div className="flex flex-col gap-1 lg:col-span-2">
          <label className="text-xs font-semibold text-pattern-muted uppercase flex items-center gap-1">
            <BarChart className="w-3 h-3" /> Aggregation
          </label>
          <select
            className="bg-pattern-input border border-pattern-border rounded px-2 py-1.5 text-xs w-full focus:ring-1 focus:ring-pattern-blue outline-none text-white"
            value={filters.timeGrain}
            onChange={(e) => onFilterChange({ ...filters, timeGrain: e.target.value as any })}
          >
            {TIME_GRAINS.map(g => (
              <option key={g.value} value={g.value}>{g.label}</option>
            ))}
          </select>
        </div>

        {/* Search Terms (4 cols) */}
        <div className="flex flex-col gap-1 lg:col-span-4">
            <label className="text-xs font-semibold text-pattern-muted uppercase flex items-center gap-1">
                <Search className="w-3 h-3" /> Search Terms
            </label>
            <div className="flex bg-pattern-input border border-pattern-border rounded text-xs w-full overflow-hidden focus-within:ring-1 focus-within:ring-pattern-blue">
                <select 
                    className="bg-slate-800 text-pattern-muted px-3 py-1.5 outline-none border-r border-pattern-border hover:text-white transition-colors cursor-pointer"
                    value={filters.keywordMatchMode}
                    onChange={(e) => onFilterChange({...filters, keywordMatchMode: e.target.value as KeywordMatchMode})}
                    title="Select match mode"
                >
                    <option value="contains">Phrase</option>
                    <option value="exact">Exact</option>
                    <option value="regex">Regex</option>
                </select>
                <input 
                    type="text"
                    className="bg-transparent text-white px-3 py-1.5 outline-none flex-grow placeholder-slate-500"
                    placeholder={filters.keywordMatchMode === 'regex' ? 'e.g. ^(nike|adidas)' : 'Filter by keyword...'}
                    value={filters.keywordFilter}
                    onChange={(e) => onFilterChange({...filters, keywordFilter: e.target.value})}
                />
                {filters.keywordFilter && (
                    <button 
                        onClick={() => onFilterChange({...filters, keywordFilter: ''})} 
                        className="px-3 text-pattern-muted hover:text-white hover:bg-slate-700 transition-colors"
                        title="Clear search"
                    >
                        <X size={14}/>
                    </button>
                )}
            </div>
        </div>

      </div>
    </div>
  );
};

export default FilterBar;