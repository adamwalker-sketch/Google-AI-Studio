import React, { useRef, useState, useEffect } from 'react';
import { Upload, FileText, AlertCircle, Database } from 'lucide-react';
import { COLORS } from '../constants';

interface FileUploadProps {
  onDataLoaded: (csvText: string) => void;
  importError?: string | null;
}

const generateSampleData = () => {
  const today = new Date();
  const rows = [];
  rows.push('date,marketplace,search_query,search_query_volume,Impressions_brand_share,Clicks_brand_share,Cart_adds_brand_share,purchases_brand_share,purchases_price_median,purchases_brand_price_median');
  
  const marketplaces = ['US', 'UK', 'DE'];
  const keywords = ['wireless headphones', 'bluetooth earbuds', 'noise cancelling headphones', 'running shoes men', 'sports sneakers', 'jogging shoes', 'gaming mouse', 'rgb mouse', 'pc accessories'];

  for (let i = 45; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(d.getDate() - i);
    const dateStr = d.toISOString().split('T')[0];
    
    marketplaces.forEach((mp, mIdx) => {
        keywords.forEach((kw, kIdx) => {
            let baseVol = mp === 'US' ? 50000 : (mp === 'UK' ? 15000 : 10000);
            baseVol = baseVol / (kIdx % 3 + 1);
            if (kIdx < 3) baseVol *= (1 + (45-i)/100);
            if (kIdx > 6) baseVol *= (1 + Math.sin(i/5) * 0.2);
            const randomVar = 0.9 + Math.random() * 0.2;
            const vol = Math.floor(baseVol * randomVar);
            
            let imp = 15 + (Math.random() * 5); 
            if (mp === 'US') imp += 5;
            imp = imp / (kIdx % 3 + 1);
            
            const click = imp * (0.6 + Math.random() * 0.1);
            const cart = click * (0.4 + Math.random() * 0.1);
            const purch = cart * (0.8 + Math.random() * 0.1);
            
            // Generate Realistic Prices
            const basePrice = 49.99 + (kIdx * 15.00);
            const marketPrice = basePrice * (1 + (Math.sin(i/10) * 0.05));
            const brandPrice = marketPrice * (0.95 + Math.random() * 0.1);
            
            rows.push(`${dateStr},${mp},${kw},${vol},${imp.toFixed(2)}%,${click.toFixed(2)}%,${cart.toFixed(2)}%,${purch.toFixed(2)}%,$${marketPrice.toFixed(2)},$${brandPrice.toFixed(2)}`);
        });
    });
  }
  return rows.join('\n');
};

const FileUpload: React.FC<FileUploadProps> = ({ onDataLoaded, importError }) => {
  const [error, setError] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (importError) setError(importError);
  }, [importError]);

  const handleFile = (file: File) => {
    if (!file.name.toLowerCase().endsWith('.csv')) {
      setError('Please upload a valid CSV file (must end with .csv).');
      return;
    }
    setError(null);
    const reader = new FileReader();
    reader.onload = (e) => {
      onDataLoaded(e.target?.result as string);
      if (fileInputRef.current) fileInputRef.current.value = '';
    };
    reader.onerror = () => setError('Error reading file.');
    reader.readAsText(file);
  };

  const handleUseSampleData = () => {
    onDataLoaded(generateSampleData());
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-[80vh] p-6">
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold text-white mb-2">Brand-Specific SQPR Dashboard</h1>
        <p className="text-pattern-muted">Upload your brand performance CSV to get started.</p>
      </div>
      <div
        className={`w-full max-w-xl p-10 border-2 border-dashed rounded-xl transition-all duration-300 flex flex-col items-center justify-center cursor-pointer bg-pattern-card shadow-lg ${isDragging ? 'border-pattern-blue bg-slate-800' : 'border-pattern-border hover:border-pattern-blue hover:bg-slate-800'}`}
        onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={(e) => { e.preventDefault(); setIsDragging(false); if (e.dataTransfer.files?.[0]) handleFile(e.dataTransfer.files[0]); }}
        onClick={() => fileInputRef.current?.click()}
      >
        <div className="bg-slate-800 p-4 rounded-full mb-4 border border-slate-700"><Upload className="w-8 h-8 text-pattern-blue" /></div>
        <p className="text-lg font-semibold text-white mb-1">Click to upload or drag and drop</p>
        <p className="text-sm text-pattern-muted mb-6">CSV files only</p>
        <input type="file" ref={fileInputRef} className="hidden" accept=".csv" onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])} />
        <div className="flex items-center gap-2 text-xs text-pattern-muted border-t border-pattern-border pt-4 w-full justify-center mt-2">
          <FileText className="w-4 h-4" /><span>Supports Brand Search Query CSV formats</span>
        </div>
      </div>
      <div className="mt-6 flex flex-col items-center">
        <div className="relative flex py-2 items-center w-full max-w-md">
            <div className="flex-grow border-t border-pattern-border"></div>
            <span className="flex-shrink mx-4 text-pattern-muted text-sm">OR</span>
            <div className="flex-grow border-t border-pattern-border"></div>
        </div>
        <button onClick={handleUseSampleData} className="mt-2 flex items-center gap-2 px-6 py-2 bg-pattern-card border border-pattern-border rounded-lg shadow-sm text-white font-medium hover:bg-slate-800 hover:border-pattern-blue hover:text-pattern-blue transition-all">
            <Database className="w-4 h-4" />Load Sample Data
        </button>
      </div>
      {error && (
        <div className="mt-4 flex items-center gap-2 text-red-200 bg-red-900/30 border border-red-900 px-4 py-2 rounded-lg max-w-xl text-center">
          <AlertCircle className="w-5 h-5 flex-shrink-0" /><span className="text-sm">{error}</span>
        </div>
      )}
    </div>
  );
};

export default FileUpload;