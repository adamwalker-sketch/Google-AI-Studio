import React, { useState, useMemo } from 'react';
import { KeywordStats } from '../types';
import { METRICS } from '../constants';
import { Search, Filter, X, ArrowUp, ArrowDown, ArrowUpDown, Bot, Loader2, Download } from 'lucide-react';

interface KeywordTableProps {
  data: KeywordStats[];
  onAnalyzeKeyword: (keyword: string) => Promise<string>;
}

type SortDirection = 'asc' | 'desc';

interface SortConfig {
  key: string;
  direction: SortDirection;
}

const KeywordTable: React.FC<KeywordTableProps> = ({ data, onAnalyzeKeyword }) => {
  const [showFilters, setShowFilters] = useState(false);
  const [filterValues, setFilterValues] = useState<Record<string, string>>({});
  const [sortConfig, setSortConfig] = useState<SortConfig>({ 
    key: 'search_query_volume', 
    direction: 'desc' 
  });
  
  // State for AI Context
  const [analyzingKeyword, setAnalyzingKeyword] = useState<string | null>(null);
  const [keywordContexts, setKeywordContexts] = useState<Record<string, string>>({});

  const handleFilterChange = (key: string, value: string) => {
    setFilterValues(prev => ({
        ...prev,
        [key]: value
    }));
  };

  const clearFilters = () => {
    setFilterValues({});
  };

  const handleSort = (key: string) => {
    setSortConfig(current => {
      if (current.key === key) {
        return { key, direction: current.direction === 'asc' ? 'desc' : 'asc' };
      }
      return { key, direction: 'desc' };
    });
  };

  const handleAnalyzeClick = async (keyword: string, e: React.MouseEvent) => {
    e.stopPropagation(); // Prevent row click/sort if any
    if (keywordContexts[keyword]) return; // Already fetched

    setAnalyzingKeyword(keyword);
    const context = await onAnalyzeKeyword(keyword);
    setKeywordContexts(prev => ({ ...prev, [keyword]: context }));
    setAnalyzingKeyword(null);
  };

  const processedData = useMemo(() => {
    // 1. Filter
    let result = data.filter(row => {
        if (filterValues['keyword'] && !row.keyword.toLowerCase().includes(filterValues['keyword'].toLowerCase())) {
            return false;
        }
        for (const metric of METRICS) {
            const filterVal = filterValues[metric.key as string];
            if (filterVal) {
                const threshold = parseFloat(filterVal);
                const rowVal = row[metric.key as string] as number;
                if (!isNaN(threshold) && rowVal < threshold) {
                    return false;
                }
            }
        }
        return true;
    });

    // 2. Sort
    if (sortConfig.key) {
      result.sort((a, b) => {
        const valA = sortConfig.key === 'keyword' ? a.keyword : (a[sortConfig.key] as number);
        const valB = sortConfig.key === 'keyword' ? b.keyword : (b[sortConfig.key] as number);

        if (valA < valB) return sortConfig.direction === 'asc' ? -1 : 1;
        if (valA > valB) return sortConfig.direction === 'asc' ? 1 : -1;
        return 0;
      });
    }

    return result;
  }, [data, filterValues, sortConfig]);

  const downloadCSV = () => {
    const headers = ['Search Term', ...METRICS.map(m => m.label), 'AI Context'];
    
    const rows = processedData.map(row => {
        const context = keywordContexts[row.keyword] || '';
        const metricValues = METRICS.map(m => row[m.key as string]);
        
        // CSV Escaping: Wrap in quotes, escape existing quotes with double quotes
        const safeKeyword = `"${row.keyword.replace(/"/g, '""')}"`;
        const safeContext = `"${context.replace(/"/g, '""')}"`;
        
        return [safeKeyword, ...metricValues, safeContext].join(',');
    });

    const csvContent = [headers.join(','), ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `keyword_performance_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const SortIcon = ({ columnKey }: { columnKey: string }) => {
    if (sortConfig.key !== columnKey) {
      return <ArrowUpDown className="w-3 h-3 text-slate-600 opacity-0 group-hover:opacity-100 transition-opacity" />;
    }
    return sortConfig.direction === 'asc' 
      ? <ArrowUp className="w-3 h-3 text-pattern-blue" />
      : <ArrowDown className="w-3 h-3 text-pattern-blue" />;
  };

  return (
    <div className="bg-[#090A0F] rounded-xl shadow-lg border border-pattern-border overflow-hidden mb-8">
      <div className="p-4 border-b border-pattern-border flex items-center justify-between">
        <div className="flex items-center gap-2">
            <Search className="w-5 h-5 text-pattern-blue" />
            <h2 className="text-lg font-bold text-white">Keyword Performance</h2>
        </div>
        <div className="flex items-center gap-2">
            {Object.keys(filterValues).some(k => filterValues[k]) && (
                <button 
                    onClick={clearFilters}
                    className="text-xs text-pattern-muted hover:text-white flex items-center gap-1 px-2 py-1 transition-colors"
                >
                    <X className="w-3 h-3" /> Clear
                </button>
            )}
            
            <button
                onClick={downloadCSV}
                className="p-2 rounded-lg transition-colors bg-slate-800 text-pattern-muted hover:text-white hover:bg-slate-700"
                title="Download CSV"
            >
                <Download className="w-4 h-4" />
            </button>

            <button
                onClick={() => setShowFilters(!showFilters)}
                className={`p-2 rounded-lg transition-colors ${showFilters ? 'bg-pattern-blue text-slate-900' : 'bg-slate-800 text-pattern-muted hover:text-white'}`}
                title="Toggle Column Filters"
            >
                <Filter className="w-4 h-4" />
            </button>
        </div>
      </div>
      <div className="overflow-x-auto max-h-96">
        <table className="w-full text-sm text-left">
          <thead className="bg-slate-800 text-pattern-muted uppercase text-xs sticky top-0 z-10 shadow-sm">
            <tr>
              <th 
                className="px-6 py-3 font-medium border-b border-pattern-border bg-slate-800 cursor-pointer group hover:bg-slate-700 transition-colors select-none"
                onClick={() => handleSort('keyword')}
              >
                <div className="flex items-center gap-2">
                  Search Term
                  <SortIcon columnKey="keyword" />
                </div>
              </th>

              {METRICS.map(m => (
                <th 
                  key={m.key} 
                  className="px-6 py-3 font-medium text-right whitespace-nowrap border-b border-pattern-border bg-slate-800 cursor-pointer group hover:bg-slate-700 transition-colors select-none"
                  onClick={() => handleSort(m.key as string)}
                >
                  <div className="flex items-center justify-end gap-2">
                    {m.label}
                    <SortIcon columnKey={m.key as string} />
                  </div>
                </th>
              ))}
              
              {/* Context Action Column */}
              <th className="px-6 py-3 font-medium border-b border-pattern-border bg-slate-800 w-10">
                <span className="sr-only">AI Context</span>
              </th>
            </tr>

            {showFilters && (
                <tr className="bg-slate-900">
                    <th className="px-6 py-2 border-b border-pattern-border">
                        <input 
                            type="text" 
                            placeholder="Contains..." 
                            className="w-full bg-slate-800 border border-slate-700 rounded px-2 py-1 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-pattern-blue transition-colors"
                            value={filterValues['keyword'] || ''}
                            onChange={(e) => handleFilterChange('keyword', e.target.value)}
                        />
                    </th>
                    {METRICS.map(m => (
                        <th key={m.key} className="px-6 py-2 border-b border-pattern-border">
                             <input 
                                type="number" 
                                placeholder="Min..." 
                                className="w-full bg-slate-800 border border-slate-700 rounded px-2 py-1 text-xs text-white placeholder-slate-500 text-right focus:outline-none focus:border-pattern-blue transition-colors"
                                value={filterValues[m.key as string] || ''}
                                onChange={(e) => handleFilterChange(m.key as string, e.target.value)}
                            />
                        </th>
                    ))}
                    <th className="px-6 py-2 border-b border-pattern-border"></th>
                </tr>
            )}
          </thead>
          <tbody className="divide-y divide-pattern-border">
            {processedData.map((row, idx) => {
              const context = keywordContexts[row.keyword];
              const isAnalyzing = analyzingKeyword === row.keyword;

              return (
                <React.Fragment key={idx}>
                  <tr className="hover:bg-slate-800/50 transition-colors">
                    <td className="px-6 py-4 font-medium text-white whitespace-nowrap max-w-xs truncate" title={row.keyword}>
                      {row.keyword}
                      {context && (
                        <div className="text-xs font-normal text-indigo-300 mt-1 whitespace-normal leading-tight">
                           ✨ {context}
                        </div>
                      )}
                    </td>
                    {METRICS.map(m => (
                      <td key={m.key} className="px-6 py-4 text-right text-pattern-muted">
                        {m.format === 'percent' 
                          ? `${(row[m.key] as number).toFixed(2)}%`
                          : (row[m.key] as number).toLocaleString()}
                      </td>
                    ))}
                    <td className="px-2 py-4 text-center">
                        <button 
                            onClick={(e) => handleAnalyzeClick(row.keyword, e)}
                            disabled={isAnalyzing || !!context}
                            className={`p-1.5 rounded-md transition-all ${
                                context 
                                    ? 'text-indigo-400 opacity-50 cursor-default' 
                                    : 'text-pattern-muted hover:text-indigo-400 hover:bg-slate-700'
                            }`}
                            title="Contextualize with Gemini & Search"
                        >
                            {isAnalyzing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Bot className="w-4 h-4" />}
                        </button>
                    </td>
                  </tr>
                </React.Fragment>
              );
            })}
            {processedData.length === 0 && (
              <tr>
                <td colSpan={METRICS.length + 2} className="px-6 py-8 text-center text-pattern-muted">
                  No keywords match the filters.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default KeywordTable;