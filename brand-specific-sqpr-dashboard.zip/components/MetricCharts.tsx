import React, { useState } from 'react';
import { AggregatedDataPoint } from '../types';
import { METRICS } from '../constants';
import { formatDateLabel } from '../services/dataProcessing';
import { logEvent } from '../services/eventLogger';
import {
  LineChart, Line, Bar, ComposedChart, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Label
} from 'recharts';
import { Maximize2, Grid, Download, Check, Plus } from 'lucide-react';

interface MetricChartsProps {
  data: AggregatedDataPoint[];
}

const MetricCharts: React.FC<MetricChartsProps> = ({ data }) => {
  // Default view to 'combined' as per previous request
  const [viewMode, setViewMode] = useState<'grid' | 'combined'>('combined');
  
  // Default combined selection: Volume + Shares (exclude prices by default for scale)
  const [selectedCombinedMetrics, setSelectedCombinedMetrics] = useState<string[]>(
    METRICS.filter(m => m.format !== 'currency').map(m => m.key as string)
  );

  const toggleMetric = (key: string) => {
    setSelectedCombinedMetrics(prev => 
      prev.includes(key) 
        ? prev.filter(k => k !== key) 
        : [...prev, key]
    );
  };

  const downloadChart = (containerId: string, title: string, withLegend: boolean = false) => {
    logEvent('DOWNLOAD_PNG', { chartTitle: title, withLegend });
    const container = document.getElementById(containerId);
    if (!container) return;
    
    const svg = container.querySelector('svg');
    if (!svg) return;

    const rect = svg.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;

    const clonedSvg = svg.cloneNode(true) as SVGElement;
    clonedSvg.setAttribute('width', width.toString());
    clonedSvg.setAttribute('height', height.toString());

    const serializer = new XMLSerializer();
    const svgString = serializer.serializeToString(clonedSvg);

    const canvas = document.createElement('canvas');
    const scale = 2;
    const legendHeight = withLegend ? 40 : 0;
    
    canvas.width = width * scale;
    canvas.height = (height + legendHeight) * scale;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.fillStyle = '#090A0F';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    const img = new Image();
    const blob = new Blob([svgString], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);

    img.onload = () => {
      ctx.drawImage(img, 0, 0, width * scale, height * scale);
      
      if (withLegend) {
          const fontSize = 10 * scale;
          ctx.font = `bold ${fontSize}px sans-serif`;
          ctx.textBaseline = 'middle';
          
          const boxSize = 10 * scale;
          const textGap = 6 * scale;
          const itemSpacing = 16 * scale;
          
          let totalWidth = 0;
          const visibleMetrics = METRICS.filter(m => viewMode === 'grid' || selectedCombinedMetrics.includes(m.key as string));
          
          visibleMetrics.forEach(m => {
              const textMetrics = ctx.measureText(m.label);
              totalWidth += boxSize + textGap + textMetrics.width + itemSpacing;
          });
          totalWidth -= itemSpacing;

          let currentX = (canvas.width - totalWidth) / 2;
          const y = (height * scale) + (legendHeight * scale / 2);

          visibleMetrics.forEach(m => {
              ctx.fillStyle = m.color;
              ctx.fillRect(currentX, y - boxSize/2, boxSize, boxSize);
              ctx.fillStyle = '#cbd5e1'; 
              ctx.fillText(m.label, currentX + boxSize + textGap, y);
              const textWidth = ctx.measureText(m.label).width;
              currentX += boxSize + textGap + textWidth + itemSpacing;
          });
      }
      
      URL.revokeObjectURL(url);
      const link = document.createElement('a');
      link.download = `${title.replace(/\s+/g, '-').toLowerCase()}-${new Date().toISOString().split('T')[0]}.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();
    };

    img.src = url;
  };

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-slate-800 border border-slate-700 p-3 rounded shadow-xl text-xs z-50">
          <p className="font-bold mb-2 text-slate-200">{formatDateLabel(label)}</p>
          {payload.map((p: any) => {
            const metric = METRICS.find(m => m.label === p.name);
            let val = p.value;
            if (metric?.format === 'percent') val = `${val.toFixed(2)}%`;
            else if (metric?.format === 'currency') val = `$${val.toFixed(2)}`;
            else val = val.toLocaleString();

            return (
                <div key={p.name} className="flex items-center gap-2 mb-1" style={{ color: p.color || p.fill }}>
                    <span className="w-2 h-2 rounded-full" style={{ backgroundColor: p.color || p.fill }}></span>
                    <span>{p.name}: {val}</span>
                </div>
            )
          })}
        </div>
      );
    }
    return null;
  };

  const renderCustomLabel = (props: any, metric: any) => {
    const { x, y, value } = props;
    if (value === null || value === undefined || x === undefined || y === undefined) return null;
    
    let formatted = '';
    if (metric.format === 'percent') formatted = `${(value as number).toFixed(1)}%`;
    else if (metric.format === 'currency') formatted = `$${(value as number).toFixed(0)}`;
    else formatted = (value as number).toLocaleString(undefined, { notation: "compact", maximumFractionDigits: 1 });

    return (
      <text 
        x={x} y={y} dy={-10} fill="#cbd5e1" fontSize={10} textAnchor="middle"
        style={{ pointerEvents: 'none', textShadow: '0px 0px 3px rgba(0,0,0,0.8)' }}
      >
        {formatted}
      </text>
    );
  };

  // --- Dynamic Axis Label Logic ---
  const leftLabelText = selectedCombinedMetrics.includes('search_query_volume') ? 'Search Volume' : '';
  
  const selectedRightMetrics = METRICS.filter(m => 
    m.key !== 'search_query_volume' && 
    selectedCombinedMetrics.includes(m.key as string)
  );
  
  let rightLabelText = '';
  if (selectedRightMetrics.length > 0) {
    const hasPercent = selectedRightMetrics.some(m => m.format === 'percent');
    const hasCurrency = selectedRightMetrics.some(m => m.format === 'currency');
    
    if (hasPercent && hasCurrency) rightLabelText = "Share (%) & Price ($)";
    else if (hasPercent) rightLabelText = "Market Share (%)";
    else if (hasCurrency) rightLabelText = "Median Price ($)";
    else rightLabelText = "Selected Values";
  }

  const axisStyle = { fontSize: 10, fill: '#94a3b8' };
  const labelStyle = { fill: '#64748b', fontSize: 11, fontWeight: 600, textAnchor: 'middle' };

  return (
    <div className="mb-8">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-bold text-white">Performance Trends</h2>
        <div className="flex bg-pattern-card rounded-lg p-1 border border-pattern-border">
          <button
            onClick={() => setViewMode('grid')}
            className={`p-2 rounded-md transition-all ${viewMode === 'grid' ? 'bg-slate-800 shadow text-pattern-blue' : 'text-pattern-muted hover:text-white'}`}
            title="Grid View"
          >
            <Grid className="w-4 h-4" />
          </button>
          <button
            onClick={() => setViewMode('combined')}
            className={`p-2 rounded-md transition-all ${viewMode === 'combined' ? 'bg-slate-800 shadow text-pattern-blue' : 'text-pattern-muted hover:text-white'}`}
            title="Combined View"
          >
            <Maximize2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {viewMode === 'grid' ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {METRICS.map(metric => (
            <div key={metric.key} className="bg-[#090A0F] p-4 rounded-xl shadow-lg border border-pattern-border">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-semibold text-pattern-muted">{metric.label}</h3>
                <button
                  onClick={() => downloadChart(`chart-container-${metric.key}`, metric.label, false)}
                  className="p-1.5 rounded-md text-pattern-muted hover:bg-slate-800 hover:text-pattern-blue transition-colors"
                  title="Download Chart PNG"
                >
                  <Download className="w-4 h-4" />
                </button>
              </div>
              <div className="h-64" id={`chart-container-${metric.key}`}>
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={data} margin={{ top: 20, right: 20, bottom: 5, left: 10 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
                    <XAxis dataKey="date" tick={axisStyle} tickLine={{ stroke: '#334155' }} axisLine={{ stroke: '#334155' }} tickFormatter={formatDateLabel} />
                    <YAxis 
                        tick={axisStyle} 
                        tickLine={{ stroke: '#334155' }} 
                        axisLine={{ stroke: '#334155' }} 
                        tickFormatter={(val) => {
                            if (metric.format === 'percent') return `${val}%`;
                            if (metric.format === 'currency') return `$${val}`;
                            return val.toLocaleString(undefined, { notation: "compact" });
                        }} 
                    />
                    <Tooltip content={<CustomTooltip />} />
                    <Line type="monotone" dataKey={metric.key} name={metric.label} stroke={metric.color} strokeWidth={2} dot={{ r: 3, fill: '#090A0F', stroke: metric.color, strokeWidth: 1 }} activeDot={{ r: 6, fill: '#090A0F', stroke: metric.color, strokeWidth: 2 }} label={(props) => renderCustomLabel(props, metric)} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-[#090A0F] p-6 rounded-xl shadow-lg border border-pattern-border">
          <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 mb-6">
            <div>
              <h3 className="text-sm font-semibold text-pattern-muted">Combined View Analysis</h3>
              <p className="text-[10px] text-slate-500 mt-1 uppercase tracking-tight font-bold">Volume vs. Market Share & Price</p>
            </div>
            <div className="flex flex-wrap gap-2 max-w-2xl">
              {METRICS.map(m => {
                const isSelected = selectedCombinedMetrics.includes(m.key as string);
                return (
                  <button
                    key={m.key}
                    onClick={() => toggleMetric(m.key as string)}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-wider transition-all border ${
                      isSelected 
                        ? 'bg-slate-800 text-white shadow-sm' 
                        : 'bg-transparent text-slate-500 border-slate-800/50 hover:border-slate-700'
                    }`}
                    style={{ borderColor: isSelected ? m.color : undefined }}
                  >
                    <div className="w-2 h-2 rounded-full" style={{ backgroundColor: m.color }}></div>
                    {m.label}
                    {isSelected ? <Check className="w-3 h-3 ml-0.5" /> : <Plus className="w-3 h-3 ml-0.5" />}
                  </button>
                );
              })}
            </div>
            <button
              onClick={() => downloadChart('chart-container-combined', 'Combined Trends', true)}
              className="p-1.5 rounded-md text-pattern-muted hover:bg-slate-800 hover:text-pattern-blue transition-colors self-end lg:self-center"
              title="Download Current Selection PNG"
            >
              <Download className="w-4 h-4" />
            </button>
          </div>

          <div className="h-[450px] w-full" id="chart-container-combined">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={data} margin={{ top: 20, right: 60, left: 60, bottom: 40 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                
                {/* X Axis with Label */}
                <XAxis 
                  dataKey="date" 
                  tick={axisStyle} 
                  tickLine={{ stroke: '#334155' }} 
                  axisLine={{ stroke: '#334155' }} 
                  tickFormatter={formatDateLabel}
                >
                  <Label value="Reporting Period" position="insideBottom" offset={-25} style={labelStyle} />
                </XAxis>
                
                {/* Primary Y Axis (Left) with Dynamic Label */}
                <YAxis 
                  yAxisId="left" 
                  tick={axisStyle} 
                  tickLine={{ stroke: '#334155' }} 
                  axisLine={{ stroke: '#334155' }} 
                  tickFormatter={(val) => val.toLocaleString(undefined, { notation: "compact" })}
                  hide={!leftLabelText}
                >
                  <Label value={leftLabelText} angle={-90} position="insideLeft" offset={-45} style={labelStyle} />
                </YAxis>
                
                {/* Secondary Y Axis (Right) with Dynamic Label */}
                <YAxis 
                  yAxisId="right" 
                  orientation="right" 
                  tick={axisStyle} 
                  tickLine={{ stroke: '#334155' }} 
                  axisLine={{ stroke: '#334155' }} 
                  tickFormatter={(val) => {
                    const onlyPrice = selectedRightMetrics.every(m => m.format === 'currency');
                    return onlyPrice ? `$${val}` : `${val}%`;
                  }}
                  hide={!rightLabelText}
                >
                  <Label value={rightLabelText} angle={90} position="insideRight" offset={-45} style={labelStyle} />
                </YAxis>
                
                <Tooltip content={<CustomTooltip />} />
                <Legend 
                  verticalAlign="top" 
                  height={36} 
                  content={({ payload }) => (
                    <div className="flex flex-wrap justify-center gap-4 text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-4">
                      {payload?.map((entry: any, index: number) => (
                        <div key={`item-${index}`} className="flex items-center gap-2">
                          <div className="w-3 h-1" style={{ backgroundColor: entry.color }}></div>
                          <span>{entry.value}</span>
                        </div>
                      ))}
                    </div>
                  )}
                />

                {METRICS.map((metric) => {
                  if (!selectedCombinedMetrics.includes(metric.key as string)) return null;

                  if (metric.key === 'search_query_volume') {
                      return (
                        <Bar 
                          key={metric.key} 
                          yAxisId="left" 
                          dataKey={metric.key} 
                          name={metric.label} 
                          fill={metric.color} 
                          barSize={30} 
                          radius={[4, 4, 0, 0]} 
                          opacity={0.6} 
                        />
                      );
                  }
                  
                  return (
                    <Line 
                      key={metric.key} 
                      yAxisId="right" 
                      type="monotone" 
                      dataKey={metric.key} 
                      name={metric.label} 
                      stroke={metric.color} 
                      strokeWidth={3} 
                      dot={{ r: 4, fill: '#090A0F', stroke: metric.color, strokeWidth: 2 }} 
                      activeDot={{ r: 8, fill: metric.color, stroke: '#fff', strokeWidth: 2 }} 
                      animationDuration={1500}
                    />
                  );
                })}
              </ComposedChart>
            </ResponsiveContainer>
          </div>
          
          <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className={`p-3 bg-slate-900/50 rounded-lg border border-slate-800 transition-opacity ${!leftLabelText ? 'opacity-30' : 'opacity-100'}`}>
               <h4 className="text-[10px] font-bold text-slate-500 uppercase mb-2">Primary Axis (Left)</h4>
               <p className="text-xs text-slate-300">Displays <span className="text-pattern-blue font-bold">Search Query Volume</span>. Tracks total market demand for selected terms.</p>
            </div>
            <div className={`p-3 bg-slate-900/50 rounded-lg border border-slate-800 transition-opacity ${!rightLabelText ? 'opacity-30' : 'opacity-100'}`}>
               <h4 className="text-[10px] font-bold text-slate-500 uppercase mb-2">Secondary Axis (Right)</h4>
               <p className="text-xs text-slate-300">Displays <span className="text-pattern-accent font-bold">Market Share %</span> and <span className="text-pattern-purple font-bold">Median Price</span>. Identifies competitive performance and pricing trends.</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MetricCharts;