import React from 'react';
import { SummaryStats } from '../types';
import { METRICS } from '../constants';
import { ArrowUp, ArrowDown, Minus } from 'lucide-react';

interface SummaryCardsProps {
  stats: SummaryStats;
  showComparison?: boolean;
}

const SummaryCards: React.FC<SummaryCardsProps> = ({ stats, showComparison = true }) => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-7 gap-4 mb-6">
      {METRICS.map(metric => {
        const stat = stats[metric.key];
        if (!stat) return null;

        const isPositive = stat.change > 0;
        const isNeutral = stat.change === 0;
        
        const formatValue = (val: number) => {
          if (metric.format === 'percent') return `${val.toFixed(2)}%`;
          if (metric.format === 'currency') return `$${val.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
          return val.toLocaleString(undefined, { maximumFractionDigits: 0 });
        };

        return (
          <div key={metric.key} className="bg-pattern-card p-4 rounded-xl shadow-lg border border-pattern-border hover:border-pattern-blue/30 transition-all flex flex-col justify-between min-h-[120px]">
            <div>
              <h3 className="text-[10px] font-bold text-pattern-muted uppercase mb-1 tracking-wider leading-tight">{metric.label}</h3>
              <div className="flex items-baseline gap-2 mb-2">
                <span className={`font-bold text-white ${metric.format === 'currency' ? 'text-xl' : 'text-2xl'}`}>
                  {formatValue(stat.current)}
                </span>
              </div>
            </div>
            
            {showComparison && (
                <div className="flex items-center text-[10px]">
                    <span className={`flex items-center font-bold px-1.5 py-0.5 rounded ${
                        isNeutral ? 'bg-slate-800 text-slate-400' :
                        isPositive ? 'bg-emerald-900/50 text-emerald-400 border border-emerald-900' : 'bg-red-900/50 text-red-400 border border-red-900'
                    }`}>
                        {isNeutral && <Minus className="w-2.5 h-2.5 mr-1" />}
                        {!isNeutral && isPositive && <ArrowUp className="w-2.5 h-2.5 mr-1" />}
                        {!isNeutral && !isPositive && <ArrowDown className="w-2.5 h-2.5 mr-1" />}
                        {Math.abs(stat.change).toFixed(1)}%
                    </span>
                    <span className="ml-2 text-pattern-muted">vs prev.</span>
                </div>
            )}
          </div>
        );
      })}
    </div>
  );
};

export default SummaryCards;